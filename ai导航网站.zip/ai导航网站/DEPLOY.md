# AI工具导航网站部署指南

## 1. 服务器要求

- Node.js 14+
- MongoDB 4.4+
- Nginx
- PM2 (用于进程管理)
- 至少1GB RAM
- 10GB 存储空间

## 2. 服务器环境准备

### 2.1 安装 Node.js
```bash
curl -fsSL https://deb.nodesource.com/setup_16.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### 2.2 安装 MongoDB
```bash
# 导入MongoDB公钥
wget -qO - https://www.mongodb.org/static/pgp/server-4.4.asc | sudo apt-key add -

# 添加MongoDB源
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/4.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-4.4.list

# 更新包列表
sudo apt-get update

# 安装MongoDB
sudo apt-get install -y mongodb-org

# 启动MongoDB
sudo systemctl start mongod
sudo systemctl enable mongod
```

### 2.3 安装 Nginx
```bash
sudo apt-get install nginx
```

### 2.4 安装 PM2
```bash
sudo npm install -g pm2
```

## 3. 项目部署

### 3.1 克隆代码
```bash
git clone [你的仓库地址] /var/www/ai-tools-nav
cd /var/www/ai-tools-nav
```

### 3.2 安装依赖
```bash
npm install --production
```

### 3.3 配置环境变量
```bash
# 创建并编辑.env文件
cp .env.example .env
nano .env

# 添加以下配置（根据实际情况修改）
PORT=3000
MONGODB_URI=mongodb://localhost:27017/ai-tools-nav
JWT_SECRET=your-secure-secret-key
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=secure-admin-password
```

### 3.4 初始化数据库
```bash
node init.js
```

### 3.5 配置 Nginx

创建Nginx配置文件：
```bash
sudo nano /etc/nginx/sites-available/ai-tools-nav
```

添加以下配置：
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # 静态文件缓存
    location /static {
        expires 30d;
        add_header Cache-Control "public, no-transform";
        proxy_pass http://localhost:3000/static;
    }

    # 上传文件大小限制
    client_max_body_size 10M;
}
```

启用站点：
```bash
sudo ln -s /etc/nginx/sites-available/ai-tools-nav /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 3.6 启动应用
```bash
pm2 start ecosystem.config.js --env production
pm2 save
```

### 3.7 配置自动启动
```bash
pm2 startup
```

## 4. SSL 配置（推荐）

### 4.1 安装 Certbot
```bash
sudo apt-get install certbot python3-certbot-nginx
```

### 4.2 获取 SSL 证书
```bash
sudo certbot --nginx -d your-domain.com
```

## 5. 维护命令

### 5.1 查看应用状态
```bash
pm2 status
```

### 5.2 查看日志
```bash
pm2 logs ai-tools-nav
```

### 5.3 重启应用
```bash
pm2 restart ai-tools-nav
```

### 5.4 更新代码
```bash
cd /var/www/ai-tools-nav
git pull
npm install --production
pm2 restart ai-tools-nav
```

## 6. 备份

### 6.1 数据库备份
```bash
# 创建备份目录
mkdir -p /var/backups/mongodb

# 备份数据库
mongodump --out /var/backups/mongodb/$(date +"%Y%m%d")

# 压缩备份
tar -zcvf /var/backups/mongodb/backup-$(date +"%Y%m%d").tar.gz /var/backups/mongodb/$(date +"%Y%m%d")
```

### 6.2 自动备份脚本
创建备份脚本：
```bash
nano /var/www/ai-tools-nav/backup.sh
```

添加以下内容：
```bash
#!/bin/bash
BACKUP_DIR="/var/backups/mongodb"
DATE=$(date +"%Y%m%d")

# 创建备份目录
mkdir -p $BACKUP_DIR

# 备份数据库
mongodump --out $BACKUP_DIR/$DATE

# 压缩备份
tar -zcvf $BACKUP_DIR/backup-$DATE.tar.gz $BACKUP_DIR/$DATE

# 删除30天前的备份
find $BACKUP_DIR -name "backup-*.tar.gz" -mtime +30 -delete
```

设置定时任务：
```bash
chmod +x /var/www/ai-tools-nav/backup.sh
crontab -e

# 添加以下行（每天凌晨3点运行备份）
0 3 * * * /var/www/ai-tools-nav/backup.sh
```

## 7. 监控

### 7.1 PM2 监控
```bash
pm2 monit
```

### 7.2 设置监控告警（可选）
```bash
pm2 install pm2-slack
pm2 set pm2-slack:webhook https://hooks.slack.com/services/xxx
```

## 8. 安全建议

1. 更新系统包：
```bash
sudo apt-get update
sudo apt-get upgrade
```

2. 配置防火墙：
```bash
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable
```

3. 设置MongoDB认证：
编辑MongoDB配置文件：
```bash
sudo nano /etc/mongod.conf
```

添加安全配置：
```yaml
security:
  authorization: enabled
```

4. 定期更新依赖包：
```bash
npm audit
npm update
```

## 9. 故障排除

### 9.1 检查服务状态
```bash
# 检查Node应用状态
pm2 status
pm2 logs

# 检查MongoDB状态
sudo systemctl status mongod

# 检查Nginx状态
sudo systemctl status nginx
```

### 9.2 常见问题解决

1. 如果网站无法访问：
- 检查防火墙设置
- 检查Nginx配置
- 检查应用日志

2. 如果数据库连接失败：
- 检查MongoDB服务状态
- 验证数据库连接字符串
- 检查数据库用户权限

3. 如果上传功能失败：
- 检查上传目录权限
- 验证Nginx客户端上传限制
- 检查磁盘空间

## 10. 性能优化

1. 启用Nginx缓存：
```nginx
# 在Nginx配置中添加
location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
    expires 30d;
    add_header Cache-Control "public, no-transform";
}
```

2. 优化MongoDB索引：
```javascript
// 为常用查询创建索引
db.tools.createIndex({ "name": 1 });
db.tools.createIndex({ "category": 1 });
db.tools.createIndex({ "createdAt": -1 });
```

3. 启用Nginx Gzip压缩：
```nginx
gzip on;
gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
```
