const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

// 初始化express应用
const app = express();

// 中间件配置
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB连接配置
const mongoURI = 'mongodb://localhost:27017/ai-tools';
console.log('正在连接到MongoDB...', mongoURI);

mongoose.connect(mongoURI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => {
    console.log('MongoDB连接成功');
    
    // 导入和初始化scheduledTasks
    try {
        const scheduledTasks = require('./services/scheduledTasks');
        scheduledTasks.init();
        console.log('定时任务初始化成功');
    } catch (error) {
        console.error('定时任务初始化失败:', error);
    }
})
.catch(err => {
    console.error('MongoDB连接失败:', err);
    process.exit(1);
});

// 路由配置
try {
    app.use('/api/tools', require('./routes/tools'));
    app.use('/api/categories', require('./routes/categories'));
    app.use('/api/admin/tools', require('./routes/toolsManagement'));
    app.use('/api/notifications', require('./routes/notifications'));
    console.log('路由配置成功');
} catch (error) {
    console.error('路由配置失败:', error);
}

// 错误处理中间件
app.use((err, req, res, next) => {
    console.error('服务器错误:', err);
    res.status(500).json({
        success: false,
        message: '服务器内部错误',
        error: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});

// 启动服务器
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`服务器运行在端口 ${PORT}`);
}).on('error', (error) => {
    console.error('服务器启动失败:', error);
});
