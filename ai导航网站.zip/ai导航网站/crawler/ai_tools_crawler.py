import requests
from bs4 import BeautifulSoup
import json
from datetime import datetime
import os
import logging
from typing import List, Dict
import time
import random
from urllib.parse import urljoin

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('crawler.log'),
        logging.StreamHandler()
    ]
)

class AIToolCrawler:
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        self.tools_data_file = '../data/ai_tools.json'
        self.ensure_data_directory()

    def ensure_data_directory(self):
        """确保数据目录存在"""
        os.makedirs(os.path.dirname(self.tools_data_file), exist_ok=True)

    def load_existing_tools(self) -> Dict:
        """加载现有的工具数据"""
        try:
            with open(self.tools_data_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return {'tools': []}

    def save_tools(self, tools_data: Dict):
        """保存工具数据"""
        with open(self.tools_data_file, 'w', encoding='utf-8') as f:
            json.dump(tools_data, f, ensure_ascii=False, indent=2)

    def crawl_futurepedia(self) -> List[Dict]:
        """爬取 Futurepedia.io 的数据"""
        tools = []
        url = 'https://www.futurepedia.io/ai-tools'
        try:
            response = requests.get(url, headers=self.headers)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            tool_cards = soup.find_all('div', class_='tool-card')
            for card in tool_cards:
                tool = {
                    'name': card.find('h3').text.strip(),
                    'description': card.find('p', class_='description').text.strip(),
                    'category': card.find('span', class_='category').text.strip(),
                    'url': card.find('a')['href'],
                    'image': card.find('img')['src'],
                    'source': 'futurepedia',
                    'crawled_date': datetime.now().isoformat()
                }
                tools.append(tool)
                time.sleep(random.uniform(1, 3))  # 随机延迟，避免被封
            
            logging.info(f'Successfully crawled {len(tools)} tools from Futurepedia')
        except Exception as e:
            logging.error(f'Error crawling Futurepedia: {str(e)}')
        
        return tools

    def crawl_toolify(self) -> List[Dict]:
        """爬取 Toolify.ai 的数据"""
        tools = []
        url = 'https://www.toolify.ai/ai-tools'
        try:
            response = requests.get(url, headers=self.headers)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            tool_cards = soup.find_all('div', class_='tool-listing')
            for card in tool_cards:
                tool = {
                    'name': card.find('h2').text.strip(),
                    'description': card.find('p', class_='description').text.strip(),
                    'category': card.find('span', class_='category').text.strip(),
                    'url': urljoin(url, card.find('a')['href']),
                    'image': card.find('img')['src'],
                    'source': 'toolify',
                    'crawled_date': datetime.now().isoformat()
                }
                tools.append(tool)
                time.sleep(random.uniform(1, 3))
            
            logging.info(f'Successfully crawled {len(tools)} tools from Toolify')
        except Exception as e:
            logging.error(f'Error crawling Toolify: {str(e)}')
        
        return tools

    def process_tools(self, new_tools: List[Dict]) -> List[Dict]:
        """处理和清洗工具数据"""
        existing_data = self.load_existing_tools()
        existing_tools = {tool['name']: tool for tool in existing_data['tools']}
        
        processed_tools = []
        for tool in new_tools:
            # 如果工具已存在，保留原有的一些信息
            if tool['name'] in existing_tools:
                existing_tool = existing_tools[tool['name']]
                tool['id'] = existing_tool.get('id')
                tool['rating'] = existing_tool.get('rating', 0)
                tool['reviews'] = existing_tool.get('reviews', [])
            else:
                # 为新工具生成ID
                tool['id'] = len(existing_tools) + len(processed_tools) + 1
                tool['rating'] = 0
                tool['reviews'] = []
            
            tool['isNew'] = (datetime.now() - datetime.fromisoformat(tool['crawled_date'])).days < 7
            processed_tools.append(tool)
        
        return processed_tools

    def update_tools(self):
        """更新工具数据"""
        # 爬取各个来源的数据
        futurepedia_tools = self.crawl_futurepedia()
        toolify_tools = self.crawl_toolify()
        
        # 合并所有来源的数据
        all_tools = futurepedia_tools + toolify_tools
        
        # 处理数据
        processed_tools = self.process_tools(all_tools)
        
        # 保存数据
        self.save_tools({'tools': processed_tools})
        logging.info(f'Successfully updated {len(processed_tools)} tools')

def main():
    crawler = AIToolCrawler()
    crawler.update_tools()

if __name__ == '__main__':
    main()
