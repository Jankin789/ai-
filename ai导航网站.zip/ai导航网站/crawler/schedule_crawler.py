import schedule
import time
from ai_tools_crawler import main as crawler_main
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('scheduler.log'),
        logging.StreamHandler()
    ]
)

def job():
    logging.info("Starting scheduled crawler job")
    try:
        crawler_main()
        logging.info("Crawler job completed successfully")
    except Exception as e:
        logging.error(f"Error in crawler job: {str(e)}")

def main():
    # 设置每天凌晨1点运行
    schedule.every().day.at("01:00").do(job)
    
    logging.info("Scheduler started")
    
    while True:
        schedule.run_pending()
        time.sleep(60)  # 每分钟检查一次

if __name__ == "__main__":
    main()
