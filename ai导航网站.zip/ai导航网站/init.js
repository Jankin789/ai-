require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

async function initializeAdmin() {
    try {
        // 连接数据库
        await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/ai-tools-nav', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log('MongoDB连接成功');

        // 检查管理员是否存在
        const adminEmail = process.env.ADMIN_EMAIL;
        let admin = await User.findOne({ email: adminEmail });

        if (!admin) {
            // 创建管理员账户
            admin = new User({
                email: adminEmail,
                password: process.env.ADMIN_PASSWORD,
                role: 'admin'
            });
            await admin.save();
            console.log('管理员账户创建成功');
        } else {
            console.log('管理员账户已存在');
        }

        console.log('初始化完成');
        process.exit(0);
    } catch (error) {
        console.error('初始化失败:', error);
        process.exit(1);
    }
}

initializeAdmin();
