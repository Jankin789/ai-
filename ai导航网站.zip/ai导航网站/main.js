// DOM Elements
const toolsContainer = document.getElementById('toolsContainer');
const searchInput = document.querySelector('.search-bar input');
const searchSuggestions = document.querySelector('.search-suggestions');
const categoryLinks = document.querySelectorAll('.category-nav a');
const filterTags = document.querySelectorAll('.filter-tags button');
const viewSwitchButtons = document.querySelectorAll('.view-switch button');
const sortSelect = document.querySelector('.sort-by select');
const themeToggle = document.querySelector('.theme-toggle');
const addToolModal = document.getElementById('addToolModal');
const addToolButton = document.querySelector('.add-tool');
const closeModalButton = document.querySelector('.close-modal');
const toolForm = document.querySelector('.tool-form');

// State
let currentTools = [];
let currentCategory = 'all';
let currentFilter = 'all';
let currentView = 'grid';
let searchQuery = '';

// Theme Toggle
themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
    const isDark = document.body.classList.contains('dark-theme');
    themeToggle.querySelector('i').className = isDark ? 'fas fa-sun' : 'fas fa-moon';
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
});

// Load saved theme
if (localStorage.getItem('theme') === 'dark') {
    document.body.classList.add('dark-theme');
    themeToggle.querySelector('i').className = 'fas fa-sun';
}

// Fetch Tools Data
async function fetchTools() {
    try {
        const response = await fetch('/data/ai_tools.json');
        const data = await response.json();
        currentTools = data.tools;
        renderTools();
    } catch (error) {
        console.error('Error fetching tools:', error);
    }
}

// Render Tools
function renderTools() {
    const filteredTools = filterTools();
    const sortedTools = sortTools(filteredTools);
    
    toolsContainer.innerHTML = sortedTools.map(tool => `
        <div class="tool-card" data-aos="fade-up">
            <img src="${tool.image}" alt="${tool.name}" class="tool-image">
            <div class="tool-content">
                <div class="tool-header">
                    <h3 class="tool-title">${tool.name}</h3>
                    <span class="tool-price ${tool.priceType}">${tool.price}</span>
                </div>
                <p class="tool-description">${tool.description}</p>
                <div class="tool-meta">
                    <div class="tool-rating">
                        <i class="fas fa-star"></i>
                        <span>${tool.rating}</span>
                    </div>
                    <span class="tool-reviews">${tool.reviewCount} 条评价</span>
                </div>
            </div>
        </div>
    `).join('');
}

// Filter Tools
function filterTools() {
    return currentTools.filter(tool => {
        const matchesCategory = currentCategory === 'all' || tool.category.toLowerCase() === currentCategory;
        const matchesFilter = currentFilter === 'all' || 
                            (currentFilter === 'new' && tool.isNew) ||
                            (currentFilter === 'popular' && tool.rating >= 4.5) ||
                            (currentFilter === 'free' && tool.priceType === 'free');
        const matchesSearch = !searchQuery || 
                            tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            tool.description.toLowerCase().includes(searchQuery.toLowerCase());
        
        return matchesCategory && matchesFilter && matchesSearch;
    });
}

// Sort Tools
function sortTools(tools) {
    const sortBy = sortSelect.value;
    return [...tools].sort((a, b) => {
        switch (sortBy) {
            case 'popular':
                return b.rating - a.rating;
            case 'new':
                return new Date(b.updateDate) - new Date(a.updateDate);
            case 'rating':
                return b.reviewCount - a.reviewCount;
            default:
                return 0;
        }
    });
}

// Event Listeners
categoryLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        categoryLinks.forEach(l => l.parentElement.classList.remove('active'));
        link.parentElement.classList.add('active');
        currentCategory = link.getAttribute('href').slice(1);
        renderTools();
    });
});

filterTags.forEach(tag => {
    tag.addEventListener('click', () => {
        filterTags.forEach(t => t.classList.remove('active'));
        tag.classList.add('active');
        currentFilter = tag.textContent.toLowerCase();
        renderTools();
    });
});

viewSwitchButtons.forEach(button => {
    button.addEventListener('click', () => {
        viewSwitchButtons.forEach(b => b.classList.remove('active'));
        button.classList.add('active');
        currentView = button.dataset.view;
        toolsContainer.className = `tools-${currentView}`;
    });
});

sortSelect.addEventListener('change', renderTools);

searchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value;
    renderTools();
    
    // Show/hide suggestions
    if (searchQuery) {
        const suggestions = currentTools
            .filter(tool => tool.name.toLowerCase().includes(searchQuery.toLowerCase()))
            .slice(0, 5);
            
        searchSuggestions.innerHTML = suggestions.map(tool => `
            <div class="suggestion-item">
                <img src="${tool.image}" alt="${tool.name}" class="suggestion-image">
                <div class="suggestion-content">
                    <h4>${tool.name}</h4>
                    <p>${tool.description.slice(0, 50)}...</p>
                </div>
            </div>
        `).join('');
        searchSuggestions.style.display = 'block';
    } else {
        searchSuggestions.style.display = 'none';
    }
});

// Modal Handling
addToolButton.addEventListener('click', () => {
    addToolModal.classList.add('active');
});

closeModalButton.addEventListener('click', () => {
    addToolModal.classList.remove('active');
});

toolForm.addEventListener('submit', (e) => {
    e.preventDefault();
    // Handle form submission
    addToolModal.classList.remove('active');
});

// Initialize
fetchTools();
