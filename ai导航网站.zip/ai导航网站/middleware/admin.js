module.exports = (req, res, next) => {
    // 检查用户角色是否为管理员
    if (req.user.role !== 'admin') {
        return res.status(403).json({ message: '需要管理员权限' });
    }
    next();
};
