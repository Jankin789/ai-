const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
    // 从请求头获取token
    const token = req.header('x-auth-token');

    // 检查是否有token
    if (!token) {
        return res.status(401).json({ message: '无访问权限，请先登录' });
    }

    try {
        // 验证token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (err) {
        res.status(401).json({ message: '无效的token' });
    }
};
