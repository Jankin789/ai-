const mongoose = require('mongoose');

const toolSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        trim: true,
        default: ''
    },
    url: {
        type: String,
        required: true,
        trim: true
    },
    category: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category',
        required: true
    },
    source: {
        type: String,
        trim: true
    },
    image: {
        type: String,
        default: '/images/default-tool.png'
    },
    views: {
        type: Number,
        default: 0
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// 添加索引
toolSchema.index({ name: 1 });
toolSchema.index({ url: 1 }, { unique: true });
toolSchema.index({ category: 1 });
toolSchema.index({ createdAt: -1 });

// 更新时间中间件
toolSchema.pre('save', function(next) {
    this.updatedAt = Date.now();
    next();
});

const Tool = mongoose.model('Tool', toolSchema);

module.exports = Tool;
