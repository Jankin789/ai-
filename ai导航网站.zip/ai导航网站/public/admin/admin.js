// API基础URL
const API_BASE_URL = '/api';

// 全局变量
let token = localStorage.getItem('token');
let currentEditId = null;

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    // 检查登录状态
    checkAuth();
    
    // 设置事件监听
    setupEventListeners();
});

// 检查认证状态
function checkAuth() {
    if (!token) {
        showLoginPage();
    } else {
        showAdminPage();
        loadDashboard();
    }
}

// 设置事件监听器
function setupEventListeners() {
    // 登录表单提交
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    
    // 导航菜单点击
    document.querySelectorAll('nav a[data-page]').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = e.target.dataset.page;
            showPage(page);
        });
    });
    
    // 退出登录
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);
    
    // 工具表单提交
    document.getElementById('toolForm').addEventListener('submit', handleToolSubmit);
    
    // 分类表单提交
    document.getElementById('categoryForm').addEventListener('submit', handleCategorySubmit);
    
    // 设置表单提交
    document.getElementById('settingsForm').addEventListener('submit', handleSettingsSubmit);
    
    // 添加工具按钮
    document.getElementById('addToolBtn').addEventListener('click', () => {
        currentEditId = null;
        showToolModal();
    });
    
    // 添加分类按钮
    document.getElementById('addCategoryBtn').addEventListener('click', () => {
        currentEditId = null;
        showCategoryModal();
    });
}

// 处理登录
async function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            token = data.token;
            localStorage.setItem('token', token);
            showAdminPage();
            loadDashboard();
        } else {
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('登录失败，请重试', 'error');
    }
}

// 处理登出
function handleLogout(e) {
    e.preventDefault();
    token = null;
    localStorage.removeItem('token');
    showLoginPage();
}

// 加载仪表盘数据
async function loadDashboard() {
    try {
        const [toolsResponse, categoriesResponse] = await Promise.all([
            fetch(`${API_BASE_URL}/tools`),
            fetch(`${API_BASE_URL}/categories`)
        ]);
        
        const [tools, categories] = await Promise.all([
            toolsResponse.json(),
            categoriesResponse.json()
        ]);
        
        // 更新统计数据
        document.getElementById('totalToolsCount').textContent = tools.length;
        document.getElementById('totalCategories').textContent = categories.length;
        document.getElementById('totalViews').textContent = tools.reduce((sum, tool) => sum + tool.views, 0);
        document.getElementById('todayNew').textContent = tools.filter(tool => tool.isNew).length;
        
    } catch (err) {
        showToast('加载数据失败', 'error');
    }
}

// 加载工具列表
async function loadTools() {
    try {
        const response = await fetch(`${API_BASE_URL}/tools`);
        const data = await response.json();
        
        const toolsList = document.getElementById('toolsList');
        toolsList.innerHTML = data.tools.map(tool => `
            <tr>
                <td class="px-6 py-4">
                    <div class="flex items-center">
                        <img src="${tool.image}" alt="${tool.name}" class="w-8 h-8 rounded mr-3">
                        ${tool.name}
                    </div>
                </td>
                <td class="px-6 py-4">${tool.category.name}</td>
                <td class="px-6 py-4">
                    <span class="px-2 py-1 rounded-full text-sm ${tool.price === '免费版本' ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'}">
                        ${tool.price}
                    </span>
                </td>
                <td class="px-6 py-4">${tool.views}</td>
                <td class="px-6 py-4">
                    <button onclick="editTool('${tool._id}')" class="text-blue-600 hover:text-blue-800 mr-3">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button onclick="deleteTool('${tool._id}')" class="text-red-600 hover:text-red-800">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    } catch (err) {
        showToast('加载工具列表失败', 'error');
    }
}

// 加载分类列表
async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE_URL}/categories`);
        const categories = await response.json();
        
        const categoriesList = document.getElementById('categoriesList');
        categoriesList.innerHTML = categories.map(category => `
            <tr>
                <td class="px-6 py-4">${category.name}</td>
                <td class="px-6 py-4">
                    <i class="${category.icon}"></i>
                </td>
                <td class="px-6 py-4">${category.toolCount || 0}</td>
                <td class="px-6 py-4">
                    <button onclick="editCategory('${category._id}')" class="text-blue-600 hover:text-blue-800 mr-3">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button onclick="deleteCategory('${category._id}')" class="text-red-600 hover:text-red-800">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    } catch (err) {
        showToast('加载分类列表失败', 'error');
    }
}

// 处理工具提交
async function handleToolSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    
    try {
        const url = currentEditId 
            ? `${API_BASE_URL}/tools/${currentEditId}`
            : `${API_BASE_URL}/tools`;
            
        const method = currentEditId ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method,
            headers: {
                'x-auth-token': token
            },
            body: formData
        });
        
        if (response.ok) {
            closeToolModal();
            loadTools();
            showToast(currentEditId ? '工具更新成功' : '工具添加成功', 'success');
        } else {
            const data = await response.json();
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('操作失败，请重试', 'error');
    }
}

// 处理分类提交
async function handleCategorySubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const category = Object.fromEntries(formData.entries());
    
    try {
        const url = currentEditId 
            ? `${API_BASE_URL}/categories/${currentEditId}`
            : `${API_BASE_URL}/categories`;
            
        const method = currentEditId ? 'PUT' : 'POST';
        
        const response = await fetch(url, {
            method,
            headers: {
                'Content-Type': 'application/json',
                'x-auth-token': token
            },
            body: JSON.stringify(category)
        });
        
        if (response.ok) {
            closeCategoryModal();
            loadCategories();
            showToast(currentEditId ? '分类更新成功' : '分类添加成功', 'success');
        } else {
            const data = await response.json();
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('操作失败，请重试', 'error');
    }
}

// 处理设置提交
async function handleSettingsSubmit(e) {
    e.preventDefault();
    
    const settings = {
        siteTitle: document.getElementById('siteTitle').value,
        siteDescription: document.getElementById('siteDescription').value,
        itemsPerPage: document.getElementById('itemsPerPage').value
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}/settings`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'x-auth-token': token
            },
            body: JSON.stringify(settings)
        });
        
        if (response.ok) {
            showToast('设置保存成功', 'success');
        } else {
            const data = await response.json();
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('保存设置失败，请重试', 'error');
    }
}

// 编辑工具
async function editTool(id) {
    currentEditId = id;
    try {
        const response = await fetch(`${API_BASE_URL}/tools/${id}`);
        const tool = await response.json();
        
        // 填充表单
        const form = document.getElementById('toolForm');
        form.name.value = tool.name;
        form.company.value = tool.company;
        form.description.value = tool.description;
        form.category.value = tool.category._id;
        form.price.value = tool.price;
        form.url.value = tool.url;
        
        showToolModal();
    } catch (err) {
        showToast('加载工具信息失败', 'error');
    }
}

// 删除工具
async function deleteTool(id) {
    if (!confirm('确定要删除这个工具吗？')) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/tools/${id}`, {
            method: 'DELETE',
            headers: {
                'x-auth-token': token
            }
        });
        
        if (response.ok) {
            loadTools();
            showToast('工具删除成功', 'success');
        } else {
            const data = await response.json();
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('删除失败，请重试', 'error');
    }
}

// 编辑分类
async function editCategory(id) {
    currentEditId = id;
    try {
        const response = await fetch(`${API_BASE_URL}/categories/${id}`);
        const category = await response.json();
        
        // 填充表单
        const form = document.getElementById('categoryForm');
        form.name.value = category.name;
        form.icon.value = category.icon;
        form.description.value = category.description;
        form.order.value = category.order;
        
        showCategoryModal();
    } catch (err) {
        showToast('加载分类信息失败', 'error');
    }
}

// 删除分类
async function deleteCategory(id) {
    if (!confirm('确定要删除这个分类吗？相关工具的分类将被设为未分类。')) return;
    
    try {
        const response = await fetch(`${API_BASE_URL}/categories/${id}`, {
            method: 'DELETE',
            headers: {
                'x-auth-token': token
            }
        });
        
        if (response.ok) {
            loadCategories();
            showToast('分类删除成功', 'success');
        } else {
            const data = await response.json();
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('删除失败，请重试', 'error');
    }
}

// 显示/隐藏页面
function showPage(pageName) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    document.querySelectorAll('nav a').forEach(link => {
        link.classList.remove('text-blue-600');
    });
    
    document.getElementById(`${pageName}Page`).classList.add('active');
    document.querySelector(`nav a[data-page="${pageName}"]`).classList.add('text-blue-600');
    
    // 加载页面数据
    switch(pageName) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'tools':
            loadTools();
            break;
        case 'categories':
            loadCategories();
            break;
    }
}

// 显示登录页面
function showLoginPage() {
    document.getElementById('loginPage').style.display = 'flex';
    document.getElementById('adminPage').style.display = 'none';
}

// 显示管理后台
function showAdminPage() {
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('adminPage').style.display = 'block';
}

// 显示工具模态框
function showToolModal() {
    document.getElementById('toolModal').classList.remove('hidden');
}

// 关闭工具模态框
function closeToolModal() {
    document.getElementById('toolModal').classList.add('hidden');
    document.getElementById('toolForm').reset();
    currentEditId = null;
}

// 显示分类模态框
function showCategoryModal() {
    document.getElementById('categoryModal').classList.remove('hidden');
}

// 关闭分类模态框
function closeCategoryModal() {
    document.getElementById('categoryModal').classList.add('hidden');
    document.getElementById('categoryForm').reset();
    currentEditId = null;
}

// 显示提示信息
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type === 'success' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`;
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}
