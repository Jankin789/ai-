// 全局状态管理
const state = {
    currentPage: 1,
    filters: {
        category: '',
        price: '',
        sort: 'rating',
        scenario: ''
    },
    searchQuery: '',
    isLoading: false
};

// DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
    loadTools();
    setupEventListeners();
});

// 初始化应用
function initializeApp() {
    // 检查用户登录状态
    checkAuthStatus();
    // 加载分类标签
    loadCategories();
    // 初始化统计数据
    loadStatistics();
    // 初始化主题
    initializeTheme();
}

// 设置事件监听器
function setupEventListeners() {
    // 搜索输入
    const searchInput = document.getElementById('searchInput');
    searchInput.addEventListener('input', debounce(handleSearch, 300));

    // 筛选器变化
    document.getElementById('priceFilter').addEventListener('change', handleFilterChange);
    document.getElementById('sortFilter').addEventListener('change', handleFilterChange);
    document.getElementById('scenarioFilter').addEventListener('change', handleFilterChange);

    // 加载更多
    document.getElementById('loadMoreBtn').addEventListener('click', loadMoreTools);

    // 返回顶部
    const backToTopButton = document.getElementById('backToTop');
    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 300) {
            backToTopButton.classList.remove('hidden');
        } else {
            backToTopButton.classList.add('hidden');
        }
    });
    backToTopButton.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

// 加载工具列表
async function loadTools(reset = false) {
    if (state.isLoading) return;
    
    if (reset) {
        state.currentPage = 1;
        document.getElementById('toolsGrid').innerHTML = '';
    }

    state.isLoading = true;
    showLoading();

    try {
        const response = await fetch(`/api/tools?${buildQueryString()}`);
        const data = await response.json();

        if (data.tools.length === 0 && state.currentPage === 1) {
            showNoResults();
        } else {
            renderTools(data.tools);
        }

        // 更新加载更多按钮状态
        updateLoadMoreButton(data.pagination);
    } catch (error) {
        console.error('Error loading tools:', error);
        showError();
    } finally {
        state.isLoading = false;
        hideLoading();
    }
}

// 渲染工具卡片
function renderTools(tools) {
    const toolsGrid = document.getElementById('toolsGrid');
    
    tools.forEach(tool => {
        const card = createToolCard(tool);
        toolsGrid.appendChild(card);
    });
}

// 创建工具卡片
function createToolCard(tool) {
    const card = document.createElement('div');
    card.className = 'bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden';
    
    card.innerHTML = `
        <div class="p-6">
            <div class="flex items-center mb-4">
                <img src="${tool.logo}" alt="${tool.name}" class="w-12 h-12 rounded-lg mr-4">
                <div>
                    <h3 class="text-lg font-semibold">${tool.name}</h3>
                    <div class="flex items-center text-sm text-gray-500">
                        <span class="flex items-center">
                            <i class="fas fa-star text-yellow-400 mr-1"></i>
                            ${tool.averageRating.toFixed(1)}
                        </span>
                        <span class="mx-2">·</span>
                        <span>${tool.pricing}</span>
                    </div>
                </div>
            </div>
            <p class="text-gray-600 mb-4">${tool.description}</p>
            <div class="flex flex-wrap gap-2 mb-4">
                ${tool.category.map(cat => `
                    <span class="px-2 py-1 bg-blue-100 text-blue-600 rounded-full text-sm">
                        ${cat}
                    </span>
                `).join('')}
            </div>
            <div class="flex justify-between items-center">
                <a href="${tool.url}" target="_blank" 
                   class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-300">
                    访问网站
                </a>
                <button class="favorite-btn p-2 text-gray-400 hover:text-red-500" data-id="${tool._id}">
                    <i class="far fa-heart"></i>
                </button>
            </div>
        </div>
    `;

    // 添加收藏功能
    const favoriteBtn = card.querySelector('.favorite-btn');
    favoriteBtn.addEventListener('click', () => toggleFavorite(tool._id));

    return card;
}

// 工具搜索处理
function handleSearch(event) {
    state.searchQuery = event.target.value;
    loadTools(true);
}

// 筛选器变化处理
function handleFilterChange(event) {
    const { id, value } = event.target;
    state.filters[id.replace('Filter', '')] = value;
    loadTools(true);
}

// 构建查询字符串
function buildQueryString() {
    const params = new URLSearchParams({
        page: state.currentPage,
        limit: 12,
        ...state.filters
    });

    if (state.searchQuery) {
        params.append('search', state.searchQuery);
    }

    return params.toString();
}

// 防抖函数
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 显示/隐藏加载状态
function showLoading() {
    // 实现加载动画
}

function hideLoading() {
    // 隐藏加载动画
}

// 显示无结果状态
function showNoResults() {
    const toolsGrid = document.getElementById('toolsGrid');
    toolsGrid.innerHTML = `
        <div class="col-span-full text-center py-12">
            <i class="fas fa-search text-4xl text-gray-400 mb-4"></i>
            <p class="text-gray-600">未找到相关工具</p>
        </div>
    `;
}

// 显示错误状态
function showError() {
    const toolsGrid = document.getElementById('toolsGrid');
    toolsGrid.innerHTML = `
        <div class="col-span-full text-center py-12">
            <i class="fas fa-exclamation-circle text-4xl text-red-500 mb-4"></i>
            <p class="text-gray-600">加载失败，请稍后重试</p>
        </div>
    `;
}

// 更新加载更多按钮状态
function updateLoadMoreButton(pagination) {
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    if (pagination.current >= pagination.total) {
        loadMoreBtn.style.display = 'none';
    } else {
        loadMoreBtn.style.display = 'block';
    }
}
