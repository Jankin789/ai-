// 认证状态管理
let authState = {
    isAuthenticated: false,
    user: null,
    token: null
};

// DOM加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    initializeAuth();
    setupAuthEventListeners();
});

// 初始化认证
function initializeAuth() {
    // 检查本地存储中的token
    const token = localStorage.getItem('token');
    if (token) {
        authState.token = token;
        checkAuthStatus();
    }
}

// 设置认证相关事件监听器
function setupAuthEventListeners() {
    // 登录/注册按钮点击
    document.getElementById('userMenuButton').addEventListener('click', () => {
        if (!authState.isAuthenticated) {
            showAuthModal();
        }
    });

    // 关闭模态框
    document.getElementById('closeAuthModal').addEventListener('click', hideAuthModal);

    // 切换登录/注册模式
    document.getElementById('toggleAuthMode').addEventListener('click', toggleAuthMode);

    // 表单提交
    document.getElementById('authForm').addEventListener('submit', handleAuthSubmit);
}

// 检查认证状态
async function checkAuthStatus() {
    if (!authState.token) return;

    try {
        const response = await fetch('/api/auth/status', {
            headers: {
                'Authorization': `Bearer ${authState.token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            updateAuthState(true, data.user);
        } else {
            // Token无效，清除状态
            logout();
        }
    } catch (error) {
        console.error('Error checking auth status:', error);
        logout();
    }
}

// 显示认证模态框
function showAuthModal() {
    document.getElementById('authModal').classList.remove('hidden');
}

// 隐藏认证模态框
function hideAuthModal() {
    document.getElementById('authModal').classList.add('hidden');
}

// 切换登录/注册模式
function toggleAuthMode() {
    const isLogin = document.getElementById('authModalTitle').textContent === '登录';
    const usernameField = document.getElementById('usernameField');
    const toggleButton = document.getElementById('toggleAuthMode');
    const submitButton = document.querySelector('#authForm button[type="submit"]');

    if (isLogin) {
        document.getElementById('authModalTitle').textContent = '注册';
        usernameField.classList.remove('hidden');
        toggleButton.textContent = '已有账号？立即登录';
        submitButton.textContent = '注册';
    } else {
        document.getElementById('authModalTitle').textContent = '登录';
        usernameField.classList.add('hidden');
        toggleButton.textContent = '没有账号？立即注册';
        submitButton.textContent = '登录';
    }
}

// 处理认证表单提交
async function handleAuthSubmit(event) {
    event.preventDefault();

    const isLogin = document.getElementById('authModalTitle').textContent === '登录';
    const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register';

    const formData = new FormData(event.target);
    const data = {
        email: formData.get('email'),
        password: formData.get('password')
    };

    if (!isLogin) {
        data.username = formData.get('username');
    }

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            const result = await response.json();
            handleAuthSuccess(result);
        } else {
            const error = await response.json();
            showAuthError(error.message);
        }
    } catch (error) {
        console.error('Auth error:', error);
        showAuthError('服务器错误，请稍后重试');
    }
}

// 处理认证成功
function handleAuthSuccess(data) {
    const { token, user } = data;
    
    // 保存token到本地存储
    localStorage.setItem('token', token);
    
    // 更新认证状态
    updateAuthState(true, user);
    
    // 隐藏模态框
    hideAuthModal();
    
    // 重置表单
    document.getElementById('authForm').reset();
    
    // 显示成功提示
    showToast('登录成功');
}

// 更新认证状态
function updateAuthState(isAuthenticated, user) {
    authState.isAuthenticated = isAuthenticated;
    authState.user = user;

    // 更新UI
    updateAuthUI();
}

// 更新认证相关UI
function updateAuthUI() {
    const userMenuButton = document.getElementById('userMenuButton');
    const userMenu = document.getElementById('userMenu');

    if (authState.isAuthenticated) {
        // 更新用户头像和名称
        document.getElementById('userAvatar').src = authState.user.avatar || '/images/default-avatar.png';
        document.getElementById('username').textContent = authState.user.username;
        
        // 更新用户菜单
        userMenu.innerHTML = `
            <a href="/profile" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                <i class="fas fa-user mr-2"></i>个人中心
            </a>
            <a href="/favorites" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                <i class="fas fa-heart mr-2"></i>我的收藏
            </a>
            <hr class="my-2">
            <button onclick="logout()" class="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100">
                <i class="fas fa-sign-out-alt mr-2"></i>退出登录
            </button>
        `;
    } else {
        // 重置为默认状态
        document.getElementById('userAvatar').src = '/images/default-avatar.png';
        document.getElementById('username').textContent = '登录/注册';
        userMenu.innerHTML = '';
    }
}

// 退出登录
function logout() {
    // 清除本地存储
    localStorage.removeItem('token');
    
    // 重置认证状态
    updateAuthState(false, null);
    
    // 显示提示
    showToast('已退出登录');
}

// 显示认证错误
function showAuthError(message) {
    // 在表单下方显示错误消息
    const errorDiv = document.createElement('div');
    errorDiv.className = 'text-red-500 text-sm mt-2';
    errorDiv.textContent = message;

    const form = document.getElementById('authForm');
    const existingError = form.querySelector('.text-red-500');
    if (existingError) {
        existingError.remove();
    }
    form.appendChild(errorDiv);
}

// 显示提示消息
function showToast(message) {
    // 创建toast元素
    const toast = document.createElement('div');
    toast.className = 'fixed bottom-4 right-4 bg-gray-800 text-white px-6 py-3 rounded-lg shadow-lg transform transition-all duration-300 translate-y-0';
    toast.textContent = message;

    // 添加到页面
    document.body.appendChild(toast);

    // 3秒后移除
    setTimeout(() => {
        toast.classList.add('translate-y-full', 'opacity-0');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}
