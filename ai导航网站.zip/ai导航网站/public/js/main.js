// DOM 元素
const toolsContainer = document.getElementById('toolsGrid');
const searchInput = document.getElementById('searchInput');
const categoryList = document.getElementById('categoryList');
const prevButton = document.getElementById('prevPage');
const nextButton = document.getElementById('nextPage');
const pageInfo = document.getElementById('currentPage');
const totalInfo = document.getElementById('totalTools');

// 状态管理
let currentPage = 1;
const itemsPerPage = 100; // 每页显示100个工具
let selectedCategory = '';
let searchQuery = '';

// 主题切换
function toggleTheme() {
    document.body.classList.toggle('dark-theme');
    const icon = document.querySelector('.theme-toggle i');
    icon.className = document.body.classList.contains('dark-theme') ? 'fas fa-sun' : 'fas fa-moon';
    localStorage.setItem('theme', document.body.classList.contains('dark-theme') ? 'dark' : 'light');
}

// 检查保存的主题
if (localStorage.getItem('theme') === 'dark') {
    document.body.classList.add('dark-theme');
    document.querySelector('.theme-toggle i').className = 'fas fa-sun';
}

// 加载分类列表
async function loadCategories() {
    try {
        console.log('正在加载分类...');
        const response = await fetch('/api/categories');
        if (!response.ok) throw new Error('加载分类失败');
        const categories = await response.json();
        console.log('加载到的分类:', categories);
        
        categoryList.innerHTML = '<li class="category-item active" data-category="">所有分类</li>';
        
        categories.forEach(category => {
            const li = document.createElement('li');
            li.className = 'category-item';
            li.setAttribute('data-category', category._id);
            li.textContent = category.name;
            categoryList.appendChild(li);
        });

        // 分类点击事件
        document.querySelectorAll('.category-item').forEach(item => {
            item.addEventListener('click', async function() {
                document.querySelectorAll('.category-item').forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                selectedCategory = this.getAttribute('data-category');
                currentPage = 1;
                await loadTools();
            });
        });
    } catch (error) {
        console.error('加载分类失败:', error);
        showError('加载分类失败，请刷新页面重试');
    }
}

// 加载工具列表
async function loadTools() {
    try {
        console.log('正在加载工具列表...');
        const url = `/api/tools?page=${currentPage}&limit=${itemsPerPage}${selectedCategory ? '&category=' + selectedCategory : ''}${searchQuery ? '&search=' + searchQuery : ''}`;
        console.log('请求URL:', url);
        
        const response = await fetch(url);
        if (!response.ok) throw new Error('加载工具失败');
        const data = await response.json();
        console.log('加载到的工具数据:', data);
        
        if (!data.tools || data.tools.length === 0) {
            toolsContainer.innerHTML = '<div class="no-tools">没有找到相关工具</div>';
            return;
        }

        const toolsHtml = data.tools.map(tool => {
            console.log('处理工具:', tool);
            return `
                <div class="tool-card">
                    <div class="tool-image">
                        <img src="${tool.image || '/images/default-tool.png'}" alt="${tool.name}" onerror="this.src='/images/default-tool.png'">
                    </div>
                    <div class="tool-info">
                        <h3>${tool.name}</h3>
                        <p>${tool.description || ''}</p>
                        <div class="tool-meta">
                            <span class="tool-category">${tool.category ? tool.category.name : '未分类'}</span>
                            ${tool.price ? `<span class="tool-price">${tool.price}</span>` : ''}
                        </div>
                        <a href="${tool.url}" target="_blank" class="visit-btn">访问网站</a>
                    </div>
                </div>
            `;
        }).join('');

        console.log('生成的HTML长度:', toolsHtml.length);
        toolsContainer.innerHTML = toolsHtml;

        // 更新分页信息
        pageInfo.textContent = `第 ${currentPage} 页 / 共 ${data.totalPages} 页`;
        prevButton.disabled = currentPage === 1;
        nextButton.disabled = currentPage >= data.totalPages;
        
        // 显示工具总数
        if (totalInfo) {
            totalInfo.textContent = `共 ${data.total} 个工具`;
        }
    } catch (error) {
        console.error('加载工具失败:', error);
        showError('加载工具失败，请刷新页面重试');
    }
}

// 工具函数：防抖
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// 显示错误信息
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    document.body.appendChild(errorDiv);
    setTimeout(() => errorDiv.remove(), 3000);
}

// 搜索框事件监听
searchInput.addEventListener('input', debounce(async function(e) {
    searchQuery = e.target.value;
    currentPage = 1;
    await loadTools();
}, 300));

// 分页按钮事件监听
prevButton.addEventListener('click', async function() {
    if (currentPage > 1) {
        currentPage--;
        await loadTools();
    }
});

nextButton.addEventListener('click', async function() {
    currentPage++;
    await loadTools();
});

// 事件监听
document.querySelector('.theme-toggle').addEventListener('click', toggleTheme);

// 初始加载
document.addEventListener('DOMContentLoaded', async function() {
    // 初始化变量
    let currentPage = 1;
    const itemsPerPage = 100; // 每页显示100个工具
    let selectedCategory = '';
    let searchQuery = '';

    // 获取DOM元素
    const toolsContainer = document.getElementById('toolsGrid') || document.querySelector('.tools-grid');
    const searchInput = document.getElementById('searchInput') || document.querySelector('.search-bar input');
    const categoryList = document.getElementById('categoryList') || document.querySelector('.categories-list');
    const prevButton = document.getElementById('prevPage') || document.querySelector('.prev-page');
    const nextButton = document.getElementById('nextPage') || document.querySelector('.next-page');
    const pageInfo = document.getElementById('currentPage') || document.querySelector('.current-page');
    const totalInfo = document.getElementById('totalTools') || document.querySelector('.total-tools');

    // 加载分类列表
    await loadCategories();
    
    // 加载工具列表
    await loadTools();

    // 搜索框事件监听
    if (searchInput) {
        searchInput.addEventListener('input', debounce(async function(e) {
            searchQuery = e.target.value;
            currentPage = 1;
            await loadTools();
        }, 300));
    }

    // 分页按钮事件监听
    if (prevButton) {
        prevButton.addEventListener('click', async function() {
            if (currentPage > 1) {
                currentPage--;
                await loadTools();
            }
        });
    }

    if (nextButton) {
        nextButton.addEventListener('click', async function() {
            currentPage++;
            await loadTools();
        });
    }

    // 加载分类列表
    async function loadCategories() {
        try {
            console.log('正在加载分类...');
            const response = await fetch('/api/categories');
            if (!response.ok) throw new Error('加载分类失败');
            const categories = await response.json();
            console.log('加载到的分类:', categories);
            
            if (categoryList) {
                categoryList.innerHTML = '<li class="category-item active" data-category="">所有分类</li>';
                
                categories.forEach(category => {
                    const li = document.createElement('li');
                    li.className = 'category-item';
                    li.setAttribute('data-category', category._id);
                    li.textContent = category.name;
                    categoryList.appendChild(li);
                });

                // 分类点击事件
                document.querySelectorAll('.category-item').forEach(item => {
                    item.addEventListener('click', async function() {
                        document.querySelectorAll('.category-item').forEach(i => i.classList.remove('active'));
                        this.classList.add('active');
                        selectedCategory = this.getAttribute('data-category');
                        currentPage = 1;
                        await loadTools();
                    });
                });
            }
        } catch (error) {
            console.error('加载分类失败:', error);
            showError('加载分类失败，请刷新页面重试');
        }
    }

    // 加载工具列表
    async function loadTools() {
        try {
            console.log('正在加载工具列表...');
            const url = `/api/tools?page=${currentPage}&limit=${itemsPerPage}${selectedCategory ? '&category=' + selectedCategory : ''}${searchQuery ? '&search=' + searchQuery : ''}`;
            console.log('请求URL:', url);
            
            const response = await fetch(url);
            if (!response.ok) throw new Error('加载工具失败');
            const data = await response.json();
            console.log('加载到的工具数据:', data);
            
            if (!data.tools || data.tools.length === 0) {
                if (toolsContainer) {
                    toolsContainer.innerHTML = '<div class="no-tools">没有找到相关工具</div>';
                }
                return;
            }

            if (toolsContainer) {
                const toolsHtml = data.tools.map(tool => {
                    console.log('处理工具:', tool);
                    return `
                        <div class="tool-card">
                            <div class="tool-image">
                                <img src="${tool.image || '/images/default-tool.png'}" alt="${tool.name}" onerror="this.src='/images/default-tool.png'">
                            </div>
                            <div class="tool-info">
                                <h3>${tool.name}</h3>
                                <p>${tool.description || ''}</p>
                                <div class="tool-meta">
                                    <span class="tool-category">${tool.category ? tool.category.name : '未分类'}</span>
                                </div>
                                <a href="${tool.url}" target="_blank" class="visit-btn">访问网站</a>
                            </div>
                        </div>
                    `;
                }).join('');

                console.log('生成的HTML长度:', toolsHtml.length);
                toolsContainer.innerHTML = toolsHtml;
            }

            // 更新分页信息
            if (pageInfo) {
                pageInfo.textContent = `第 ${currentPage} 页 / 共 ${data.totalPages} 页`;
            }
            if (prevButton) {
                prevButton.disabled = currentPage === 1;
            }
            if (nextButton) {
                nextButton.disabled = currentPage >= data.totalPages;
            }
            
            // 显示工具总数
            if (totalInfo) {
                totalInfo.textContent = `共 ${data.total} 个工具`;
            }
        } catch (error) {
            console.error('加载工具失败:', error);
            showError('加载工具失败，请刷新页面重试');
        }
    }

    // 工具函数：防抖
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // 显示错误信息
    function showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        document.body.appendChild(errorDiv);
        setTimeout(() => errorDiv.remove(), 3000);
    }
});
