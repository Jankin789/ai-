// 搜索功能管理
const searchState = {
    suggestions: [],
    searchHistory: [],
    isLoading: false
};

// 初始化搜索功能
function initializeSearch() {
    const searchInput = document.getElementById('searchInput');
    const suggestionsContainer = document.getElementById('searchSuggestions');

    // 加载搜索历史
    loadSearchHistory();

    // 设置事件监听器
    searchInput.addEventListener('input', debounce(handleSearchInput, 300));
    searchInput.addEventListener('focus', showSearchSuggestions);
    document.addEventListener('click', handleClickOutside);

    // 添加键盘导航
    searchInput.addEventListener('keydown', handleSearchKeydown);
}

// 处理搜索输入
async function handleSearchInput(event) {
    const query = event.target.value.trim();
    
    if (!query) {
        showSearchHistory();
        return;
    }

    searchState.isLoading = true;
    updateSearchUI();

    try {
        const response = await fetch(`/api/search/suggestions?q=${encodeURIComponent(query)}`);
        const suggestions = await response.json();
        
        searchState.suggestions = suggestions;
        showSearchSuggestions();
    } catch (error) {
        console.error('Error fetching suggestions:', error);
        searchState.suggestions = [];
    } finally {
        searchState.isLoading = false;
        updateSearchUI();
    }
}

// 显示搜索建议
function showSearchSuggestions() {
    const suggestionsContainer = document.getElementById('searchSuggestions');
    const query = document.getElementById('searchInput').value.trim();

    if (!query) {
        showSearchHistory();
        return;
    }

    let html = '';

    if (searchState.isLoading) {
        html = '<div class="p-4 text-center text-gray-500">正在搜索...</div>';
    } else if (searchState.suggestions.length === 0) {
        html = '<div class="p-4 text-center text-gray-500">无搜索建议</div>';
    } else {
        html = searchState.suggestions.map(suggestion => `
            <div class="suggestion-item p-3 hover:bg-gray-100 cursor-pointer flex items-center">
                <i class="fas fa-search text-gray-400 mr-3"></i>
                <div>
                    <div class="font-medium">${highlightMatch(suggestion.name, query)}</div>
                    <div class="text-sm text-gray-500">${suggestion.category.join(' · ')}</div>
                </div>
            </div>
        `).join('');
    }

    suggestionsContainer.innerHTML = html;
    suggestionsContainer.classList.remove('hidden');

    // 添加点击事件
    const items = suggestionsContainer.querySelectorAll('.suggestion-item');
    items.forEach((item, index) => {
        item.addEventListener('click', () => {
            selectSuggestion(searchState.suggestions[index]);
        });
    });
}

// 显示搜索历史
function showSearchHistory() {
    const suggestionsContainer = document.getElementById('searchSuggestions');
    
    if (searchState.searchHistory.length === 0) {
        suggestionsContainer.classList.add('hidden');
        return;
    }

    const html = `
        <div class="p-3 border-b border-gray-200">
            <div class="flex justify-between items-center">
                <span class="text-sm text-gray-500">搜索历史</span>
                <button id="clearHistory" class="text-sm text-blue-600 hover:text-blue-700">
                    清除历史
                </button>
            </div>
        </div>
        ${searchState.searchHistory.map(item => `
            <div class="suggestion-item p-3 hover:bg-gray-100 cursor-pointer flex items-center justify-between">
                <div class="flex items-center">
                    <i class="fas fa-history text-gray-400 mr-3"></i>
                    <span>${item}</span>
                </div>
                <button class="delete-history text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `).join('')}
    `;

    suggestionsContainer.innerHTML = html;
    suggestionsContainer.classList.remove('hidden');

    // 添加事件监听器
    document.getElementById('clearHistory').addEventListener('click', clearSearchHistory);
    
    const deleteButtons = suggestionsContainer.querySelectorAll('.delete-history');
    deleteButtons.forEach((button, index) => {
        button.addEventListener('click', (e) => {
            e.stopPropagation();
            removeFromHistory(index);
        });
    });

    const historyItems = suggestionsContainer.querySelectorAll('.suggestion-item');
    historyItems.forEach((item, index) => {
        item.addEventListener('click', () => {
            const query = searchState.searchHistory[index];
            document.getElementById('searchInput').value = query;
            performSearch(query);
        });
    });
}

// 选择搜索建议
function selectSuggestion(suggestion) {
    const searchInput = document.getElementById('searchInput');
    searchInput.value = suggestion.name;
    
    // 添加到搜索历史
    addToSearchHistory(suggestion.name);
    
    // 执行搜索
    performSearch(suggestion.name);
    
    // 隐藏建议框
    hideSearchSuggestions();
}

// 执行搜索
function performSearch(query) {
    // 更新搜索状态
    state.searchQuery = query;
    
    // 重新加载工具列表
    loadTools(true);
    
    // 添加到搜索历史
    addToSearchHistory(query);
}

// 处理键盘导航
function handleSearchKeydown(event) {
    const suggestionsContainer = document.getElementById('searchSuggestions');
    const items = suggestionsContainer.querySelectorAll('.suggestion-item');
    const activeItem = suggestionsContainer.querySelector('.suggestion-item.active');
    let activeIndex = Array.from(items).indexOf(activeItem);

    switch (event.key) {
        case 'ArrowDown':
            event.preventDefault();
            if (activeIndex < items.length - 1) {
                if (activeItem) activeItem.classList.remove('active', 'bg-gray-100');
                items[activeIndex + 1].classList.add('active', 'bg-gray-100');
            }
            break;

        case 'ArrowUp':
            event.preventDefault();
            if (activeIndex > 0) {
                if (activeItem) activeItem.classList.remove('active', 'bg-gray-100');
                items[activeIndex - 1].classList.add('active', 'bg-gray-100');
            }
            break;

        case 'Enter':
            if (activeItem) {
                event.preventDefault();
                selectSuggestion(searchState.suggestions[activeIndex]);
            }
            break;

        case 'Escape':
            hideSearchSuggestions();
            break;
    }
}

// 处理点击外部
function handleClickOutside(event) {
    const searchContainer = document.getElementById('searchInput').parentElement;
    if (!searchContainer.contains(event.target)) {
        hideSearchSuggestions();
    }
}

// 隐藏搜索建议
function hideSearchSuggestions() {
    document.getElementById('searchSuggestions').classList.add('hidden');
}

// 高亮匹配文本
function highlightMatch(text, query) {
    const regex = new RegExp(`(${query})`, 'gi');
    return text.replace(regex, '<span class="bg-yellow-200">$1</span>');
}

// 加载搜索历史
function loadSearchHistory() {
    const history = localStorage.getItem('searchHistory');
    if (history) {
        searchState.searchHistory = JSON.parse(history);
    }
}

// 添加到搜索历史
function addToSearchHistory(query) {
    query = query.trim();
    if (!query) return;

    // 移除重复项
    searchState.searchHistory = searchState.searchHistory.filter(item => item !== query);
    
    // 添加到开头
    searchState.searchHistory.unshift(query);
    
    // 限制历史记录数量
    if (searchState.searchHistory.length > 10) {
        searchState.searchHistory.pop();
    }

    // 保存到本地存储
    saveSearchHistory();
}

// 从历史记录中移除
function removeFromHistory(index) {
    searchState.searchHistory.splice(index, 1);
    saveSearchHistory();
    showSearchHistory();
}

// 清除搜索历史
function clearSearchHistory() {
    searchState.searchHistory = [];
    saveSearchHistory();
    hideSearchSuggestions();
}

// 保存搜索历史
function saveSearchHistory() {
    localStorage.setItem('searchHistory', JSON.stringify(searchState.searchHistory));
}

// 更新搜索UI
function updateSearchUI() {
    const searchInput = document.getElementById('searchInput');
    const loadingIcon = searchInput.parentElement.querySelector('.fas.fa-search');
    
    if (searchState.isLoading) {
        loadingIcon.classList.add('animate-spin');
    } else {
        loadingIcon.classList.remove('animate-spin');
    }
}

// 初始化
document.addEventListener('DOMContentLoaded', initializeSearch);
