// 主题管理
const themeState = {
    current: 'light'
};

// 初始化主题
function initializeTheme() {
    // 检查本地存储中的主题设置
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        setTheme(savedTheme);
    } else {
        // 检查系统主题偏好
        if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
            setTheme('dark');
        }
    }

    // 监听系统主题变化
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        if (!localStorage.getItem('theme')) {
            setTheme(e.matches ? 'dark' : 'light');
        }
    });

    // 设置主题切换按钮事件
    document.getElementById('themeToggle').addEventListener('click', toggleTheme);
}

// 切换主题
function toggleTheme() {
    setTheme(themeState.current === 'light' ? 'dark' : 'light');
}

// 设置主题
function setTheme(theme) {
    themeState.current = theme;
    
    // 更新HTML类
    if (theme === 'dark') {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }

    // 更新主题图标
    const themeIcon = document.querySelector('#themeToggle i');
    themeIcon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';

    // 保存到本地存储
    localStorage.setItem('theme', theme);

    // 更新UI颜色
    updateThemeColors(theme);
}

// 更新UI颜色
function updateThemeColors(theme) {
    const root = document.documentElement;
    
    if (theme === 'dark') {
        root.style.setProperty('--bg-primary', '#1a1a1a');
        root.style.setProperty('--bg-secondary', '#2d2d2d');
        root.style.setProperty('--text-primary', '#ffffff');
        root.style.setProperty('--text-secondary', '#a0a0a0');
        root.style.setProperty('--border-color', '#404040');
    } else {
        root.style.setProperty('--bg-primary', '#ffffff');
        root.style.setProperty('--bg-secondary', '#f3f4f6');
        root.style.setProperty('--text-primary', '#111827');
        root.style.setProperty('--text-secondary', '#6b7280');
        root.style.setProperty('--border-color', '#e5e7eb');
    }
}

// 导出主题状态供其他模块使用
window.themeState = themeState;
