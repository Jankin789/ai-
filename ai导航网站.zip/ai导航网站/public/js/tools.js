// 工具相关功能管理
let toolsState = {
    currentCategory: 'all',
    searchTerm: '',
    tools: [],
    statistics: {
        total: 0,
        free: 0,
        categories: 0
    }
};

// 加载分类
async function loadCategories() {
    try {
        const response = await fetch('/api/categories');
        const categories = await response.json();
        toolsState.categories = categories;
        renderCategories(categories);
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

// 渲染分类标签
function renderCategories(categories) {
    const categoryTags = document.getElementById('categoryTags');
    categoryTags.innerHTML = `
        <button class="category-btn active px-4 py-2 rounded-full bg-blue-100 text-blue-600 hover:bg-blue-200 transition-colors duration-300">
            <i class="fas fa-globe mr-2"></i>全部
        </button>
        ${categories.map(category => `
            <button class="category-btn px-4 py-2 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors duration-300">
                <i class="fas ${getCategoryIcon(category)} mr-2"></i>${category}
            </button>
        `).join('')}
    `;

    // 添加点击事件
    const buttons = categoryTags.querySelectorAll('.category-btn');
    buttons.forEach(button => {
        button.addEventListener('click', () => {
            buttons.forEach(btn => btn.classList.remove('active', 'bg-blue-100', 'text-blue-600'));
            button.classList.add('active', 'bg-blue-100', 'text-blue-600');
            
            const category = button.textContent.trim();
            toolsState.currentCategory = category === '全部' ? 'all' : category;
            loadTools();
        });
    });
}

// 获取分类图标
function getCategoryIcon(category) {
    const iconMap = {
        '文本生成': 'fa-pen',
        '图像生成': 'fa-image',
        '代码助手': 'fa-code',
        '视频制作': 'fa-video',
        '音频处理': 'fa-music',
        '办公效率': 'fa-briefcase',
        '教育学习': 'fa-graduation-cap',
        '数据分析': 'fa-chart-bar',
        '设计创意': 'fa-paint-brush',
        '营销推广': 'fa-bullhorn'
    };

    return iconMap[category] || 'fa-tag';
}

// 加载统计数据
async function loadStatistics() {
    try {
        const response = await fetch('/api/statistics');
        const statistics = await response.json();
        toolsState.statistics = statistics;
        updateStatistics(statistics);
    } catch (error) {
        console.error('Error loading statistics:', error);
    }
}

// 更新统计数据显示
function updateStatistics(statistics) {
    document.getElementById('totalTools').textContent = statistics.total;
    document.getElementById('freeTools').textContent = statistics.free;
    document.getElementById('totalCategories').textContent = statistics.categories;
    document.getElementById('todayNew').textContent = statistics.todayNew;
}

// 切换收藏状态
async function toggleFavorite(toolId) {
    if (!authState.isAuthenticated) {
        showAuthModal();
        return;
    }

    try {
        const endpoint = `/api/tools/${toolId}/favorite`;
        const method = toolsState.favorites.has(toolId) ? 'DELETE' : 'POST';

        const response = await fetch(endpoint, {
            method,
            headers: {
                'Authorization': `Bearer ${authState.token}`
            }
        });

        if (response.ok) {
            if (method === 'POST') {
                toolsState.favorites.add(toolId);
                showToast('已添加到收藏');
            } else {
                toolsState.favorites.delete(toolId);
                showToast('已取消收藏');
            }
            updateFavoriteButton(toolId);
        }
    } catch (error) {
        console.error('Error toggling favorite:', error);
        showToast('操作失败，请稍后重试');
    }
}

// 更新收藏按钮状态
function updateFavoriteButton(toolId) {
    const button = document.querySelector(`.favorite-btn[data-id="${toolId}"]`);
    if (button) {
        const icon = button.querySelector('i');
        if (toolsState.favorites.has(toolId)) {
            icon.classList.remove('far');
            icon.classList.add('fas', 'text-red-500');
        } else {
            icon.classList.remove('fas', 'text-red-500');
            icon.classList.add('far');
        }
    }
}

// 加载用户收藏
async function loadFavorites() {
    if (!authState.isAuthenticated) return;

    try {
        const response = await fetch('/api/user/favorites', {
            headers: {
                'Authorization': `Bearer ${authState.token}`
            }
        });

        if (response.ok) {
            const favorites = await response.json();
            toolsState.favorites = new Set(favorites.map(f => f._id));
            updateAllFavoriteButtons();
        }
    } catch (error) {
        console.error('Error loading favorites:', error);
    }
}

// 更新所有收藏按钮状态
function updateAllFavoriteButtons() {
    document.querySelectorAll('.favorite-btn').forEach(button => {
        const toolId = button.dataset.id;
        updateFavoriteButton(toolId);
    });
}

// 提交新工具
async function submitTool(toolData) {
    if (!authState.isAuthenticated) {
        showAuthModal();
        return;
    }

    try {
        const response = await fetch('/api/tools/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authState.token}`
            },
            body: JSON.stringify(toolData)
        });

        if (response.ok) {
            showToast('工具提交成功，等待审核');
            return true;
        } else {
            const error = await response.json();
            showToast(error.message || '提交失败，请稍后重试');
            return false;
        }
    } catch (error) {
        console.error('Error submitting tool:', error);
        showToast('提交失败，请稍后重试');
        return false;
    }
}

// 评分和评论
async function rateTool(toolId, score, review) {
    if (!authState.isAuthenticated) {
        showAuthModal();
        return;
    }

    try {
        const response = await fetch(`/api/tools/${toolId}/rate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authState.token}`
            },
            body: JSON.stringify({ score, review })
        });

        if (response.ok) {
            showToast('评价提交成功');
            return true;
        } else {
            const error = await response.json();
            showToast(error.message || '评价失败，请稍后重试');
            return false;
        }
    } catch (error) {
        console.error('Error rating tool:', error);
        showToast('评价失败，请稍后重试');
        return false;
    }
}

// 工具数据加载和过滤
async function loadTools(category = 'all') {
    try {
        const response = await fetch('data/tools.json');
        const data = await response.json();
        const tools = data.tools;
        
        // 根据分类过滤工具
        const filteredTools = category === 'all' 
            ? tools 
            : tools.filter(tool => tool.category === category);
        
        // 清空现有内容
        const toolsGrid = document.getElementById('toolsGrid');
        toolsGrid.innerHTML = '';
        
        // 添加工具卡片
        filteredTools.forEach(tool => {
            const card = createToolCard(tool);
            toolsGrid.appendChild(card);
        });
        
        // 添加淡入动画
        const cards = toolsGrid.querySelectorAll('.tool-card');
        cards.forEach((card, index) => {
            card.style.animation = `fadeIn 0.5s ease forwards ${index * 0.1}s`;
        });
    } catch (error) {
        console.error('Error loading tools:', error);
        const toolsGrid = document.getElementById('toolsGrid');
        toolsGrid.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>加载失败，请稍后重试</p>
            </div>
        `;
    }
}

// 创建工具卡片
function createToolCard(tool) {
    const card = document.createElement('div');
    card.className = 'tool-card';
    
    // 处理标签
    const tagsHtml = tool.tags 
        ? tool.tags.map(tag => `<span class="tool-tag">${tag}</span>`).join('') 
        : '';
    
    // 处理评分星星
    const ratingStars = generateRatingStars(tool.rating);
    
    // 处理价格标签
    const priceClass = tool.price.includes('免费') ? 'free' : 'paid';
    
    // 设置默认图片
    const defaultImage = '/images/default-tool.png';
    const imageUrl = tool.image || defaultImage;
    
    card.innerHTML = `
        <div class="tool-image-container">
            <img src="${imageUrl}" 
                 alt="${tool.name}" 
                 class="tool-image" 
                 loading="lazy"
                 onerror="this.onerror=null; this.src='${defaultImage}'; this.classList.add('image-error');">
        </div>
        <div class="tool-content">
            <div class="tool-header">
                <h3 class="tool-title">${tool.name}</h3>
                <span class="tool-company">${tool.company}</span>
            </div>
            <p class="tool-description">${tool.description}</p>
            <div class="tool-meta">
                <div class="tool-rating">
                    <div class="rating-stars">${ratingStars}</div>
                    <span class="rating-value">${tool.rating}</span>
                </div>
                <span class="tool-tag ${priceClass}">${tool.price}</span>
            </div>
            <div class="tool-tags">
                ${tagsHtml}
            </div>
        </div>
        <div class="tool-footer">
            <a href="${tool.url}" class="tool-link primary-btn" target="_blank" rel="noopener noreferrer">
                <span>访问网站</span>
                <i class="fas fa-external-link-alt"></i>
            </a>
            <button class="tool-action-btn secondary-btn" onclick="shareToolUrl('${tool.url}', '${tool.name}')">
                <i class="fas fa-share-alt"></i>
            </button>
            <button class="tool-action-btn secondary-btn" onclick="addToFavorites('${tool.name}')">
                <i class="fas fa-bookmark"></i>
            </button>
        </div>
    `;
    
    return card;
}

// 生成评分星星
function generateRatingStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    
    return `
        ${`<i class="fas fa-star"></i>`.repeat(fullStars)}
        ${hasHalfStar ? `<i class="fas fa-star-half-alt"></i>` : ''}
        ${`<i class="far fa-star"></i>`.repeat(emptyStars)}
    `;
}

// 分享工具链接
function shareToolUrl(url, name) {
    if (navigator.share) {
        navigator.share({
            title: name,
            text: `查看这个很棒的AI工具：${name}`,
            url: url
        }).catch(console.error);
    } else {
        // 复制到剪贴板
        navigator.clipboard.writeText(url).then(() => {
            alert('链接已复制到剪贴板！');
        }).catch(console.error);
    }
}

// 添加到收藏
function addToFavorites(toolName) {
    let favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
    const index = favorites.indexOf(toolName);
    
    if (index === -1) {
        favorites.push(toolName);
        alert(`${toolName} 已添加到收藏！`);
    } else {
        favorites.splice(index, 1);
        alert(`${toolName} 已从收藏中移除！`);
    }
    
    localStorage.setItem('favorites', JSON.stringify(favorites));
}

// 初始化分类切换
function initCategoryButtons() {
    const categoryButtons = document.querySelectorAll('.category-btn');
    
    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            // 移除其他按钮的激活状态
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            // 添加当前按钮的激活状态
            button.classList.add('active');
            
            // 加载对应分类的工具
            const category = button.dataset.category;
            loadTools(category);
        });
    });
}

// 初始化搜索功能
function initSearch() {
    const searchInput = document.getElementById('search');
    const toolsGrid = document.getElementById('toolsGrid');
    let debounceTimer;
    
    searchInput.addEventListener('input', (e) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(async () => {
            const searchTerm = e.target.value.toLowerCase();
            
            try {
                const response = await fetch('data/tools.json');
                const data = await response.json();
                const tools = data.tools;
                
                // 过滤工具
                const filteredTools = tools.filter(tool => {
                    const searchString = `${tool.name} ${tool.description} ${tool.tags?.join(' ')}`.toLowerCase();
                    return searchString.includes(searchTerm);
                });
                
                // 清空并重新渲染
                toolsGrid.innerHTML = '';
                filteredTools.forEach(tool => {
                    const card = createToolCard(tool);
                    toolsGrid.appendChild(card);
                });
                
                // 添加动画
                const cards = toolsGrid.querySelectorAll('.tool-card');
                cards.forEach((card, index) => {
                    card.style.animation = `fadeIn 0.5s ease forwards ${index * 0.1}s`;
                });
            } catch (error) {
                console.error('Error searching tools:', error);
            }
        }, 300); // 300ms 防抖
    });
}

// 主题切换
function initThemeToggle() {
    const themeSelect = document.querySelector('.theme-select');
    const body = document.body;

    // 从localStorage获取保存的主题
    const savedTheme = localStorage.getItem('selected-theme') || 'theme-cyberpunk';
    body.setAttribute('data-theme', savedTheme);
    themeSelect.value = savedTheme;

    // 监听主题选择变化
    themeSelect.addEventListener('change', () => {
        const selectedTheme = themeSelect.value;
        
        // 移除所有主题类
        const themes = [
            'theme-cyberpunk',
            'theme-minimal',
            'theme-nature',
            'theme-ocean',
            'theme-sunset',
            'theme-galaxy',
            'theme-retro',
            'theme-neon',
            'theme-holographic'
        ];
        
        // 设置新主题
        body.setAttribute('data-theme', selectedTheme);
        localStorage.setItem('selected-theme', selectedTheme);

        // 添加过渡动画
        document.documentElement.style.setProperty('--transition-speed', '0.3s');
        setTimeout(() => {
            document.documentElement.style.setProperty('--transition-speed', '0s');
        }, 300);
    });
}

// 确保在页面加载完成后初始化主题
document.addEventListener('DOMContentLoaded', () => {
    loadTools(); // 加载所有工具
    initCategoryButtons(); // 初始化分类按钮
    initSearch(); // 初始化搜索功能
    initThemeToggle(); // 初始化主题切换
});
