const express = require('express');
const router = express.Router();
const Category = require('../models/Category');
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');

// 获取所有分类
router.get('/', async (req, res) => {
    try {
        const categories = await Category.find().sort('order');
        res.json(categories);
    } catch (err) {
        res.status(500).json({ message: '服务器错误' });
    }
});

// 创建分类（需要管理员权限）
router.post('/', [auth, admin], async (req, res) => {
    try {
        const category = new Category(req.body);
        await category.save();
        res.status(201).json(category);
    } catch (err) {
        res.status(500).json({ message: '服务器错误' });
    }
});

// 更新分类（需要管理员权限）
router.put('/:id', [auth, admin], async (req, res) => {
    try {
        const category = await Category.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );
        
        if (!category) {
            return res.status(404).json({ message: '分类不存在' });
        }
        
        res.json(category);
    } catch (err) {
        res.status(500).json({ message: '服务器错误' });
    }
});

// 删除分类（需要管理员权限）
router.delete('/:id', [auth, admin], async (req, res) => {
    try {
        const category = await Category.findByIdAndDelete(req.params.id);
        
        if (!category) {
            return res.status(404).json({ message: '分类不存在' });
        }
        
        res.json({ message: '分类已删除' });
    } catch (err) {
        res.status(500).json({ message: '服务器错误' });
    }
});

module.exports = router;
