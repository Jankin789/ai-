const express = require('express');
const router = express.Router();
const { getUnreadNotifications, markNotificationAsRead } = require('../utils/notification');

// 获取未读通知
router.get('/unread', async (req, res) => {
    try {
        const notifications = await getUnreadNotifications();
        res.json({
            success: true,
            notifications
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '获取通知失败',
            error: error.message
        });
    }
});

// 标记通知为已读
router.post('/:id/read', async (req, res) => {
    try {
        const success = await markNotificationAsRead(req.params.id);
        if (success) {
            res.json({
                success: true,
                message: '已标记为已读'
            });
        } else {
            res.status(400).json({
                success: false,
                message: '标记失败'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '操作失败',
            error: error.message
        });
    }
});

module.exports = router;
