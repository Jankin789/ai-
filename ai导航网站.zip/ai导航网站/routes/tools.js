const express = require('express');
const router = express.Router();
const Tool = require('../models/Tool');
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');
const multer = require('multer');
const path = require('path');
const Category = require('../models/Category');

// 配置文件上传
const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: function(req, file, cb) {
        cb(null, 'tool-' + Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 1000000 },
    fileFilter: function(req, file, cb) {
        checkFileType(file, cb);
    }
}).single('image');

// 检查文件类型
function checkFileType(file, cb) {
    const filetypes = /jpeg|jpg|png|gif/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);

    if (mimetype && extname) {
        return cb(null, true);
    } else {
        cb('Error: Images Only!');
    }
}

// 获取所有工具
router.get('/', async (req, res) => {
    try {
        const { category, search, page = 1, limit = 100 } = req.query;
        const query = {};

        if (category) {
            query.category = category;
        }

        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { description: { $regex: search, $options: 'i' } }
            ];
        }

        const tools = await Tool.find(query)
            .populate('category')
            .sort({ createdAt: -1 })
            .skip((page - 1) * limit)
            .limit(parseInt(limit));

        const total = await Tool.countDocuments(query);

        res.json({
            tools,
            total,
            totalPages: Math.ceil(total / limit),
            currentPage: parseInt(page)
        });
    } catch (err) {
        console.error('获取工具列表失败:', err);
        res.status(500).json({ message: '服务器错误' });
    }
});

// 获取单个工具
router.get('/:id', async (req, res) => {
    try {
        const tool = await Tool.findById(req.params.id).populate('category');
        if (!tool) {
            return res.status(404).json({ message: '工具不存在' });
        }
        
        // 增加查看次数
        tool.views += 1;
        await tool.save();
        
        res.json(tool);
    } catch (err) {
        console.error('获取工具详情失败:', err);
        res.status(500).json({ message: '服务器错误' });
    }
});

// 创建工具（需要管理员权限）
router.post('/', [auth, admin], async (req, res) => {
    upload(req, res, async (err) => {
        if (err) {
            return res.status(400).json({ message: err });
        }

        if (!req.file) {
            return res.status(400).json({ message: '请上传图片' });
        }

        try {
            const tool = new Tool({
                ...req.body,
                image: `/uploads/${req.file.filename}`
            });

            await tool.save();
            res.status(201).json(tool);
        } catch (err) {
            res.status(500).json({ message: '服务器错误' });
        }
    });
});

// 更新工具（需要管理员权限）
router.put('/:id', [auth, admin], async (req, res) => {
    upload(req, res, async (err) => {
        if (err) {
            return res.status(400).json({ message: err });
        }

        try {
            const updateData = { ...req.body };
            if (req.file) {
                updateData.image = `/uploads/${req.file.filename}`;
            }

            const tool = await Tool.findByIdAndUpdate(
                req.params.id,
                updateData,
                { new: true }
            );

            if (!tool) {
                return res.status(404).json({ message: '工具不存在' });
            }

            res.json(tool);
        } catch (err) {
            res.status(500).json({ message: '服务器错误' });
        }
    });
});

// 删除工具（需要管理员权限）
router.delete('/:id', [auth, admin], async (req, res) => {
    try {
        const tool = await Tool.findByIdAndDelete(req.params.id);
        if (!tool) {
            return res.status(404).json({ message: '工具不存在' });
        }
        res.json({ message: '工具已删除' });
    } catch (err) {
        res.status(500).json({ message: '服务器错误' });
    }
});

module.exports = router;
