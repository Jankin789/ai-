const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const AiToolsCrawler = require('../services/crawler');
const ToolsImporter = require('../services/importer');

// 配置文件上传
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/imports')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname))
    }
});

const upload = multer({ storage: storage });

// 手动触发爬虫
router.post('/crawl', async (req, res) => {
    try {
        console.log('开始爬虫任务...');
        const crawler = new AiToolsCrawler();
        const newToolsCount = await crawler.crawl();
        console.log(`爬虫完成，新增 ${newToolsCount} 个工具`);
        
        res.json({
            success: true,
            message: `成功抓取 ${newToolsCount} 个新工具`
        });
    } catch (error) {
        console.error('爬虫运行失败:', error);
        res.status(500).json({
            success: false,
            message: '爬虫运行失败',
            error: error.message
        });
    }
});

// 从CSV文件导入工具
router.post('/import/csv', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: '请上传CSV文件'
            });
        }

        const importer = new ToolsImporter();
        const results = await importer.importFromCsv(req.file.path);
        
        res.json({
            success: true,
            message: '导入完成',
            results
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '导入失败',
            error: error.message
        });
    }
});

// 从JSON文件导入工具
router.post('/import/json', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: '请上传JSON文件'
            });
        }

        const importer = new ToolsImporter();
        const results = await importer.importFromJson(req.file.path);
        
        res.json({
            success: true,
            message: '导入完成',
            results
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '导入失败',
            error: error.message
        });
    }
});

// 生成导入模板
router.get('/templates/:type', (req, res) => {
    const { type } = req.params;
    const templatesDir = path.join(__dirname, '../public/templates');
    
    try {
        if (type === 'csv') {
            ToolsImporter.generateCsvTemplate(path.join(templatesDir, 'tools_template.csv'));
            res.download(path.join(templatesDir, 'tools_template.csv'));
        } else if (type === 'json') {
            ToolsImporter.generateJsonTemplate(path.join(templatesDir, 'tools_template.json'));
            res.download(path.join(templatesDir, 'tools_template.json'));
        } else {
            res.status(400).json({
                success: false,
                message: '不支持的模板类型'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            message: '生成模板失败',
            error: error.message
        });
    }
});

module.exports = router;
