// 全局变量
let tools = [];
let currentView = 'grid';
let currentTheme = localStorage.getItem('theme') || 'light';

// DOM 加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
});

// 初始化应用
async function initializeApp() {
    setupEventListeners();
    setTheme(currentTheme);
    await loadTools();
}

// 设置事件监听器
function setupEventListeners() {
    // 主题切换
    const themeToggle = document.getElementById('themeToggle');
    themeToggle.addEventListener('click', toggleTheme);

    // 菜单切换
    const menuToggle = document.getElementById('menuToggle');
    menuToggle.addEventListener('click', () => {
        document.getElementById('sidebar').classList.toggle('active');
    });

    // 搜索功能
    const searchInput = document.getElementById('searchInput');
    searchInput.addEventListener('input', debounce(handleSearch, 300));

    // 视图切换
    document.querySelectorAll('.view-toggle').forEach(button => {
        button.addEventListener('click', () => {
            currentView = button.dataset.view;
            document.querySelectorAll('.view-toggle').forEach(btn => {
                btn.classList.remove('active');
            });
            button.classList.add('active');
            renderTools(tools);
        });
    });

    // 标签点击
    document.querySelectorAll('.tag').forEach(tag => {
        tag.addEventListener('click', () => {
            document.querySelectorAll('.tag').forEach(t => t.classList.remove('active'));
            tag.classList.add('active');
            filterTools(tag.textContent);
        });
    });

    // 提交工具按钮
    const submitToolBtn = document.querySelector('.submit-tool-btn');
    submitToolBtn.addEventListener('click', () => {
        document.getElementById('submitModal').style.display = 'flex';
    });

    // 关闭模态框
    document.querySelector('.close-modal').addEventListener('click', () => {
        document.getElementById('submitModal').style.display = 'none';
    });

    // 工具提交表单
    document.getElementById('submitForm').addEventListener('submit', handleSubmit);

    // 加载更多按钮
    document.querySelector('.load-more').addEventListener('click', loadMore);
}

// 加载工具数据
async function loadTools() {
    try {
        const response = await fetch('data/ai_tools.json');
        const data = await response.json();
        tools = data.tools;
        renderTools(tools);
    } catch (error) {
        console.error('Error loading tools:', error);
        showError('加载工具数据失败，请稍后重试');
    }
}

// 渲染工具卡片
function renderTools(toolsToRender) {
    const container = document.getElementById('toolsContainer');
    container.innerHTML = toolsToRender.map(tool => createToolCard(tool)).join('');
}

// 创建工具卡片
function createToolCard(tool) {
    return `
        <div class="tool-card">
            <div class="tool-image">
                <img src="${tool.image || 'https://via.placeholder.com/300x200'}" alt="${tool.name}">
                <div class="tool-badge">${tool.category || '热门'}</div>
            </div>
            <div class="tool-content">
                <h3>${tool.name}</h3>
                <p>${tool.description}</p>
                <div class="tool-meta">
                    <div class="tool-rating">
                        <i class="fas fa-star"></i>
                        <span>${tool.rating || '4.9'}</span>
                    </div>
                    <div class="tool-stats">
                        <span><i class="fas fa-eye"></i> ${tool.views || '1.2k'}</span>
                        <span><i class="fas fa-heart"></i> ${tool.likes || '328'}</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// 搜索处理
function handleSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    const filtered = tools.filter(tool => 
        tool.name.toLowerCase().includes(searchTerm) ||
        tool.description.toLowerCase().includes(searchTerm) ||
        tool.tags.some(tag => tag.toLowerCase().includes(searchTerm))
    );
    renderTools(filtered);
}

// 过滤工具
function filterTools(tag) {
    if (tag === '全部') {
        renderTools(tools);
        return;
    }
    
    const filtered = tools.filter(tool => 
        tool.tags.includes(tag) || 
        tool.category === tag
    );
    renderTools(filtered);
}

// 处理工具提交
function handleSubmit(event) {
    event.preventDefault();
    // 这里添加提交逻辑
    document.getElementById('submitModal').style.display = 'none';
    showSuccess('工具提交成功！');
}

// 切换主题
function toggleTheme() {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    setTheme(currentTheme);
    localStorage.setItem('theme', currentTheme);
}

// 设置主题
function setTheme(theme) {
    document.body.classList.toggle('dark-theme', theme === 'dark');
    const icon = document.querySelector('#themeToggle i');
    icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
}

// 工具函数
function truncateText(text, length) {
    return text.length > length ? text.substring(0, length) + '...' : text;
}

function formatNumber(num) {
    return num > 1000 ? (num/1000).toFixed(1) + 'k' : num;
}

function getPriceLabel(priceType) {
    const labels = {
        'free': '免费',
        'paid': '付费',
        'subscription': '订阅'
    };
    return labels[priceType] || priceType;
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function showSuccess(message) {
    // 这里可以添加toast提示
    console.log('Success:', message);
}

function showError(message) {
    // 这里可以添加toast提示
    console.error('Error:', message);
}

// 加载更多
function loadMore() {
    // 这里添加加载更多逻辑
    console.log('Loading more tools...');
}

// 工具数据
let toolsData = [];
let currentCategory = 'all';
let currentView = 'grid';
let isLoading = false;

// DOM 加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
    setupEventListeners();
});

// 初始化应用
function initializeApp() {
    loadTools();
    setupThemeToggle();
    setupSearch();
    setupCategoryNav();
    setupViewToggle();
}

// 设置事件监听器
function setupEventListeners() {
    // 分类点击事件
    document.querySelectorAll('.category-nav a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const category = e.currentTarget.getAttribute('href').replace('#', '');
            switchCategory(category);
        });
    });

    // 标签点击事件
    document.querySelectorAll('.filter-tags button').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.filter-tags button').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filterTools(btn.textContent.toLowerCase());
        });
    });

    // 视图切换事件
    document.querySelectorAll('.view-switch button').forEach(btn => {
        btn.addEventListener('click', () => {
            const view = btn.getAttribute('data-view');
            switchView(view);
        });
    });

    // 添加工具按钮事件
    document.querySelector('.add-tool').addEventListener('click', () => {
        showAddToolModal();
    });

    // 加载更多按钮事件
    document.querySelector('.load-more button').addEventListener('click', loadMoreTools);
}

// 加载工具数据
async function loadTools() {
    try {
        isLoading = true;
        updateLoadingState();
        
        // 这里替换为实际的API调用
        const response = await fetch('tools.json');
        const data = await response.json();
        
        toolsData = data;
        renderTools(toolsData);
    } catch (error) {
        console.error('加载工具数据失败:', error);
        showError('加载数据失败，请稍后重试');
    } finally {
        isLoading = false;
        updateLoadingState();
    }
}

// 渲染工具卡片
function renderTools(tools) {
    const container = document.getElementById('toolsContainer');
    container.innerHTML = tools.map(tool => createToolCard(tool)).join('');
    
    // 添加动画效果
    container.querySelectorAll('.tool-card').forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.classList.add('fade-in');
    });
}

// 创建工具卡片
function createToolCard(tool) {
    return `
        <div class="tool-card">
            <div class="tool-image">
                <img src="${tool.image || 'placeholder.jpg'}" alt="${tool.name}" loading="lazy">
                <div class="tool-badge">${tool.category}</div>
            </div>
            <div class="tool-content">
                <h3>${tool.name}</h3>
                <p>${tool.description}</p>
                <div class="tool-meta">
                    <div class="tool-rating">
                        <i class="fas fa-star"></i>
                        <span>${tool.rating || '4.5'}</span>
                    </div>
                    <div class="tool-stats">
                        <span><i class="fas fa-eye"></i> ${formatNumber(tool.views || 0)}</span>
                        <span><i class="fas fa-heart"></i> ${formatNumber(tool.likes || 0)}</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// 切换分类
function switchCategory(category) {
    currentCategory = category;
    document.querySelectorAll('.category-nav li').forEach(li => {
        li.classList.toggle('active', li.querySelector('a').getAttribute('href') === `#${category}`);
    });
    
    const filteredTools = category === 'all' 
        ? toolsData 
        : toolsData.filter(tool => tool.category.toLowerCase() === category);
    
    renderTools(filteredTools);
}

// 切换视图
function switchView(view) {
    currentView = view;
    const container = document.getElementById('toolsContainer');
    container.className = `tools-${view}`;
    
    document.querySelectorAll('.view-switch button').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-view') === view);
    });
}

// 搜索功能
function setupSearch() {
    const searchInput = document.querySelector('.search-bar input');
    let debounceTimer;

    searchInput.addEventListener('input', (e) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            const query = e.target.value.toLowerCase();
            const filteredTools = toolsData.filter(tool => 
                tool.name.toLowerCase().includes(query) ||
                tool.description.toLowerCase().includes(query)
            );
            renderTools(filteredTools);
        }, 300);
    });
}

// 主题切换
function setupThemeToggle() {
    const themeToggle = document.querySelector('.theme-toggle');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    
    // 检查系统主题
    if (prefersDark.matches) {
        document.body.classList.add('dark-theme');
        themeToggle.querySelector('i').classList.replace('fa-moon', 'fa-sun');
    }
    
    themeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-theme');
        const icon = themeToggle.querySelector('i');
        icon.classList.toggle('fa-moon');
        icon.classList.toggle('fa-sun');
    });
}

// 工具提交模态框
function showAddToolModal() {
    const modal = document.getElementById('addToolModal');
    modal.classList.add('active');
    
    modal.querySelector('.close-modal').addEventListener('click', () => {
        modal.classList.remove('active');
    });
    
    modal.querySelector('form').addEventListener('submit', handleToolSubmit);
}

// 处理工具提交
async function handleToolSubmit(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    
    try {
        // 这里替换为实际的API调用
        const response = await fetch('/api/tools', {
            method: 'POST',
            body: formData
        });
        
        if (response.ok) {
            showSuccess('工具提交成功！');
            document.getElementById('addToolModal').classList.remove('active');
            form.reset();
            loadTools(); // 重新加载工具列表
        } else {
            throw new Error('提交失败');
        }
    } catch (error) {
        showError('提交失败，请稍后重试');
    }
}

// 工具函数
function formatNumber(num) {
    return num > 999 ? (num/1000).toFixed(1) + 'k' : num;
}

function showError(message) {
    // 实现错误提示
}

function showSuccess(message) {
    // 实现成功提示
}

function updateLoadingState() {
    const loadMoreBtn = document.querySelector('.load-more button');
    loadMoreBtn.disabled = isLoading;
    loadMoreBtn.innerHTML = isLoading ? 
        '<i class="fas fa-spinner fa-spin"></i> 加载中...' : 
        '<span>加载更多</span><i class="fas fa-arrow-right"></i>';
}
