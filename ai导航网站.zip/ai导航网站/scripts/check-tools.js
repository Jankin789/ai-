const mongoose = require('mongoose');
const Tool = require('../models/Tool');
const Category = require('../models/Category');

async function checkTools() {
    try {
        console.log('正在连接到MongoDB...');
        await mongoose.connect('mongodb://localhost:27017/ai-tools', {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 10000,
            connectTimeoutMS: 10000
        });
        console.log('MongoDB连接成功');

        console.log('正在查询工具数据...');
        const tools = await Tool.find().lean();
        
        if (tools.length === 0) {
            console.log('数据库中没有工具数据');
        } else {
            console.log(`\n找到 ${tools.length} 个工具:`);
            for (const tool of tools) {
                let categoryName = '未分类';
                if (tool.category) {
                    const category = await Category.findById(tool.category).lean();
                    if (category) {
                        categoryName = category.name;
                    }
                }
                console.log(`- ${tool.name} (${categoryName})`);
            }
        }

    } catch (error) {
        console.error('操作失败:', error.message);
        if (error.name === 'MongoTimeoutError') {
            console.error('MongoDB连接超时，请检查MongoDB服务是否正常运行');
        }
    } finally {
        try {
            await mongoose.disconnect();
            console.log('MongoDB连接已关闭');
        } catch (error) {
            console.error('关闭连接失败:', error.message);
        }
        process.exit(0);
    }
}

// 设置全局超时
setTimeout(() => {
    console.error('脚本执行超时，强制退出');
    process.exit(1);
}, 30000);

checkTools();
