const mongoose = require('mongoose');
const fs = require('fs').promises;
const path = require('path');
const dotenv = require('dotenv');

// 加载环境变量
dotenv.config();

// 导入模型
const Category = require('../models/Category');
const Tool = require('../models/Tool');

// 连接数据库
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/ai-tools-nav', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB连接成功'))
.catch(err => console.error('MongoDB连接失败:', err));

async function importData() {
    try {
        // 读取数据文件
        const categoriesData = JSON.parse(
            await fs.readFile(path.join(__dirname, '../data/categories.json'), 'utf-8')
        );
        const toolsData = JSON.parse(
            await fs.readFile(path.join(__dirname, '../data/tools.json'), 'utf-8')
        );

        // 清空现有数据
        await Category.deleteMany({});
        await Tool.deleteMany({});

        // 导入分类
        const categories = await Category.insertMany(
            categoriesData.categories.map(cat => ({
                name: cat.name,
                icon: cat.icon,
                description: cat.description,
                slug: cat.slug
            }))
        );

        // 创建分类映射
        const categoryMap = {};
        categories.forEach(cat => {
            categoryMap[cat.slug] = cat._id;
        });

        // 导入工具
        const tools = await Tool.insertMany(
            toolsData.tools.map(tool => ({
                name: tool.name,
                company: tool.company,
                description: tool.description,
                category: categoryMap[tool.category],
                price: tool.price,
                url: tool.url,
                image: tool.image,
                tags: tool.tags,
                rating: tool.rating
            }))
        );

        console.log(`成功导入 ${categories.length} 个分类和 ${tools.length} 个工具`);
        process.exit(0);
    } catch (error) {
        console.error('导入数据时出错:', error);
        process.exit(1);
    }
}

importData();
