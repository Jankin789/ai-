const mongoose = require('mongoose');
const fs = require('fs').promises;
const path = require('path');
const Tool = require('../models/Tool');
const Category = require('../models/Category');

// 连接到MongoDB
mongoose.connect('mongodb://localhost:27017/ai-tools', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('MongoDB连接成功');
}).catch(err => {
    console.error('MongoDB连接失败:', err);
    process.exit(1);
});

// 生成slug的函数
function generateSlug(name) {
    return name
        .toLowerCase()
        .replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '-')
        .replace(/^-+|-+$/g, '');
}

async function importTools() {
    try {
        // 读取JSON文件
        const dataPath = path.join(__dirname, '../data/initial-tools.json');
        const data = JSON.parse(await fs.readFile(dataPath, 'utf8'));
        
        console.log(`读取到 ${data.tools.length} 个工具`);
        
        // 导入每个工具
        for (const toolData of data.tools) {
            try {
                // 获取或创建分类
                let category = await Category.findOne({ name: toolData.category });
                if (!category) {
                    category = await Category.create({
                        name: toolData.category,
                        slug: generateSlug(toolData.category),
                        icon: 'fas fa-robot',
                        description: `${toolData.category}相关工具`
                    });
                    console.log(`创建新分类: ${toolData.category}`);
                }
                
                // 检查工具是否已存在
                const existingTool = await Tool.findOne({
                    $or: [
                        { name: toolData.name },
                        { url: toolData.url }
                    ]
                });
                
                if (!existingTool) {
                    // 创建新工具
                    const tool = new Tool({
                        name: toolData.name,
                        slug: generateSlug(toolData.name),
                        description: toolData.description,
                        company: toolData.company,
                        price: toolData.price,
                        image: toolData.image,
                        url: toolData.url,
                        category: category._id,
                        tags: toolData.tags,
                        rating: 0,
                        ratingCount: 0,
                        isNew: true,
                        createdAt: new Date()
                    });
                    
                    await tool.save();
                    console.log(`导入工具: ${toolData.name}`);
                } else {
                    console.log(`工具已存在，跳过: ${toolData.name}`);
                }
            } catch (error) {
                console.error(`导入工具 ${toolData.name} 失败:`, error);
            }
        }
        
        console.log('导入完成');
        process.exit(0);
    } catch (error) {
        console.error('导入失败:', error);
        process.exit(1);
    }
}

// 运行导入
importTools();
