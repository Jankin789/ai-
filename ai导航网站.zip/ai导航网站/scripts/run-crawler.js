const mongoose = require('mongoose');
const crawler = require('../services/crawler');

async function main() {
    try {
        // 连接数据库
        await mongoose.connect('mongodb://localhost:27017/ai-tools', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });
        console.log('MongoDB连接成功');

        // 运行爬虫
        await crawler.start();

        // 关闭数据库连接
        await mongoose.disconnect();
        console.log('爬虫任务完成');
        process.exit(0);
    } catch (error) {
        console.error('爬虫运行失败:', error);
        process.exit(1);
    }
}

main();
