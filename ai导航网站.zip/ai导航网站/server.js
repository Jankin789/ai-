const express = require('express');
const path = require('path');
const fs = require('fs').promises;

const app = express();

// 中间件
app.use(express.json());
app.use(express.static('public'));
app.use('/uploads', express.static('uploads'));

// API路由
// 获取所有分类
app.get('/api/categories', async (req, res) => {
    try {
        const data = await fs.readFile(path.join(__dirname, 'public/data/categories.json'), 'utf8');
        res.json(JSON.parse(data));
    } catch (error) {
        res.status(500).json({ error: '获取分类失败' });
    }
});

// 获取所有工具
app.get('/api/tools', async (req, res) => {
    try {
        const data = await fs.readFile(path.join(__dirname, 'public/data/tools.json'), 'utf8');
        res.json(JSON.parse(data));
    } catch (error) {
        res.status(500).json({ error: '获取工具失败' });
    }
});

// 获取特色功能
app.get('/api/features', async (req, res) => {
    try {
        const data = await fs.readFile(path.join(__dirname, 'public/data/features.json'), 'utf8');
        res.json(JSON.parse(data));
    } catch (error) {
        res.status(500).json({ error: '获取特色功能失败' });
    }
});

// 获取教程列表
app.get('/api/tutorials', async (req, res) => {
    try {
        const data = await fs.readFile(path.join(__dirname, 'public/data/tutorials.json'), 'utf8');
        res.json(JSON.parse(data));
    } catch (error) {
        res.status(500).json({ error: '获取教程失败' });
    }
});

// 获取工具对比
app.get('/api/comparisons', async (req, res) => {
    try {
        const data = await fs.readFile(path.join(__dirname, 'public/data/comparisons.json'), 'utf8');
        res.json(JSON.parse(data));
    } catch (error) {
        res.status(500).json({ error: '获取对比数据失败' });
    }
});

// 获取特定分类的工具
app.get('/api/tools/category/:category', async (req, res) => {
    try {
        const data = await fs.readFile(path.join(__dirname, 'public/data/tools.json'), 'utf8');
        const tools = JSON.parse(data).tools;
        const categoryTools = tools.filter(tool => tool.category === req.params.category);
        res.json({ tools: categoryTools });
    } catch (error) {
        res.status(500).json({ error: '获取分类工具失败' });
    }
});

// 搜索工具
app.get('/api/tools/search', async (req, res) => {
    try {
        const { q } = req.query;
        const data = await fs.readFile(path.join(__dirname, 'public/data/tools.json'), 'utf8');
        const tools = JSON.parse(data).tools;
        const searchResults = tools.filter(tool => 
            tool.name.toLowerCase().includes(q.toLowerCase()) ||
            tool.description.toLowerCase().includes(q.toLowerCase()) ||
            tool.tags.some(tag => tag.toLowerCase().includes(q.toLowerCase()))
        );
        res.json({ tools: searchResults });
    } catch (error) {
        res.status(500).json({ error: '搜索失败' });
    }
});

// 前端路由
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// 启动服务器
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`服务器运行在 http://localhost:${PORT}`);
});
