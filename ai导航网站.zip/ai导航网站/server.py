from http.server import HTTPServer, SimpleHTTPRequestHandler
import json
import os

class CustomHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        # 处理根路径请求
        if self.path == '/':
            self.path = '/index.html'
        
        # 处理 /data/ai_tools.json 请求
        if self.path == '/data/ai_tools.json':
            try:
                with open('data/ai_tools.json', 'rb') as f:
                    self.send_response(200)
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    self.wfile.write(f.read())
                    return
            except FileNotFoundError:
                self.send_error(404, 'File not found')
                return
        
        return SimpleHTTPRequestHandler.do_GET(self)

    def end_headers(self):
        # 添加 CORS 头
        self.send_header('Access-Control-Allow-Origin', '*')
        SimpleHTTPRequestHandler.end_headers(self)

def run(server_class=HTTPServer, handler_class=CustomHandler, port=8080):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f'Starting server on port {port}...')
    httpd.serve_forever()

if __name__ == '__main__':
    run()
