const mongoose = require('mongoose');

const toolSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true
    },
    category: [{
        type: String,
        required: true
    }],
    url: {
        type: String,
        required: true
    },
    logo: {
        type: String,
        required: true
    },
    pricing: {
        type: String,
        enum: ['free', 'freemium', 'paid'],
        required: true
    },
    priceRange: {
        min: Number,
        max: Number,
        currency: {
            type: String,
            default: 'USD'
        }
    },
    features: [{
        type: String
    }],
    ratings: [{
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        score: {
            type: Number,
            min: 1,
            max: 5
        },
        review: String,
        date: {
            type: Date,
            default: Date.now
        }
    }],
    averageRating: {
        type: Number,
        default: 0
    },
    totalRatings: {
        type: Number,
        default: 0
    },
    views: {
        type: Number,
        default: 0
    },
    status: {
        type: String,
        enum: ['active', 'pending', 'inactive'],
        default: 'active'
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

// 更新平均评分的中间件
toolSchema.pre('save', function(next) {
    if (this.ratings.length > 0) {
        const totalScore = this.ratings.reduce((acc, curr) => acc + curr.score, 0);
        this.averageRating = totalScore / this.ratings.length;
        this.totalRatings = this.ratings.length;
    }
    next();
});

module.exports = mongoose.model('Tool', toolSchema);
