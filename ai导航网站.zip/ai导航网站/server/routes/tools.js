const express = require('express');
const router = express.Router();
const Tool = require('../models/Tool');
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');

// 获取工具列表（支持分页和过滤）
router.get('/', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 12;
        const category = req.query.category;
        const pricing = req.query.pricing;
        const search = req.query.search;
        const sort = req.query.sort || 'createdAt';

        let query = {};
        
        // 搜索过滤
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { description: { $regex: search, $options: 'i' } }
            ];
        }

        // 分类过滤
        if (category) {
            query.category = category;
        }

        // 价格类型过滤
        if (pricing) {
            query.pricing = pricing;
        }

        // 获取总数
        const total = await Tool.countDocuments(query);

        // 获取工具列表
        const tools = await Tool.find(query)
            .sort({ [sort]: -1 })
            .skip((page - 1) * limit)
            .limit(limit);

        res.json({
            tools,
            pagination: {
                current: page,
                total: Math.ceil(total / limit),
                limit
            }
        });
    } catch (error) {
        res.status(500).json({ message: '服务器错误', error: error.message });
    }
});

// 获取工具详情
router.get('/:id', async (req, res) => {
    try {
        const tool = await Tool.findById(req.params.id);
        if (!tool) {
            return res.status(404).json({ message: '工具不存在' });
        }
        
        // 增加查看次数
        tool.views += 1;
        await tool.save();

        res.json(tool);
    } catch (error) {
        res.status(500).json({ message: '服务器错误', error: error.message });
    }
});

// 添加工具评分和评论
router.post('/:id/rate', auth, async (req, res) => {
    try {
        const { score, review } = req.body;
        const tool = await Tool.findById(req.params.id);
        
        if (!tool) {
            return res.status(404).json({ message: '工具不存在' });
        }

        // 检查用户是否已经评价过
        const existingRating = tool.ratings.find(
            rating => rating.user.toString() === req.user.userId
        );

        if (existingRating) {
            existingRating.score = score;
            existingRating.review = review;
        } else {
            tool.ratings.push({
                user: req.user.userId,
                score,
                review
            });
        }

        await tool.save();
        res.json(tool);
    } catch (error) {
        res.status(500).json({ message: '服务器错误', error: error.message });
    }
});

// 管理员添加新工具
router.post('/', [auth, admin], async (req, res) => {
    try {
        const tool = new Tool(req.body);
        await tool.save();
        res.status(201).json(tool);
    } catch (error) {
        res.status(500).json({ message: '服务器错误', error: error.message });
    }
});

// 管理员更新工具
router.put('/:id', [auth, admin], async (req, res) => {
    try {
        const tool = await Tool.findByIdAndUpdate(
            req.params.id,
            { ...req.body, updatedAt: Date.now() },
            { new: true }
        );
        
        if (!tool) {
            return res.status(404).json({ message: '工具不存在' });
        }
        
        res.json(tool);
    } catch (error) {
        res.status(500).json({ message: '服务器错误', error: error.message });
    }
});

module.exports = router;
