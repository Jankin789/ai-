const axios = require('axios');
const cheerio = require('cheerio');
const Tool = require('../models/Tool');
const Category = require('../models/Category');

class AiToolsCrawler {
    constructor() {
        this.sources = [
            {
                url: 'https://www.toolify.ai/ai-tools',
                selector: '.tool-list-item',
                nameSelector: '.tool-name',
                descriptionSelector: '.tool-description',
                urlSelector: '.tool-link',
                categorySelector: '.tool-category'
            }
        ];
    }

    async start() {
        console.log('开始爬取工具...');
        try {
            // 模拟API调用获取工具列表
            const tools = [
                {
                    name: "ChatGPT",
                    description: "OpenAI开发的大型语言模型，能够进行自然语言对话和完成各种任务。",
                    url: "https://chat.openai.com",
                    category: "聊天机器人"
                },
                {
                    name: "Midjourney",
                    description: "AI艺术和图像生成工具，可以创建高质量的艺术作品。",
                    url: "https://www.midjourney.com",
                    category: "图像生成"
                },
                {
                    name: "Claude",
                    description: "Anthropic开发的AI助手，擅长写作、分析和问答。",
                    url: "https://www.anthropic.com/claude",
                    category: "AI助手"
                },
                {
                    name: "DALL-E",
                    description: "OpenAI的AI图像生成模型，可以根据文本描述创建图像。",
                    url: "https://labs.openai.com",
                    category: "图像生成"
                },
                {
                    name: "Stable Diffusion",
                    description: "开源的AI图像生成模型，可以创建各种风格的图像。",
                    url: "https://stability.ai",
                    category: "图像生成"
                },
                {
                    name: "Notion AI",
                    description: "集成在Notion中的AI助手，帮助写作和组织内容。",
                    url: "https://www.notion.so",
                    category: "写作助手"
                },
                {
                    name: "Copy.ai",
                    description: "AI驱动的文案写作工具，帮助创建营销文案。",
                    url: "https://www.copy.ai",
                    category: "写作助手"
                },
                {
                    name: "Jasper",
                    description: "AI写作助手，可以生成博客文章、社交媒体内容等。",
                    url: "https://www.jasper.ai",
                    category: "写作助手"
                },
                {
                    name: "Synthesia",
                    description: "AI视频生成平台，可以创建带有虚拟主持人的视频。",
                    url: "https://www.synthesia.io",
                    category: "视频生成"
                },
                {
                    name: "RunwayML",
                    description: "创意工具套件，包含视频编辑、图像生成等功能。",
                    url: "https://runwayml.com",
                    category: "创意工具"
                }
            ];

            console.log(`准备保存 ${tools.length} 个工具`);
            await this.saveTools(tools, "预设数据");
            
            console.log('爬虫任务完成');
        } catch (error) {
            console.error('爬虫运行失败:', error);
            throw error;
        }
    }

    async saveTools(tools, sourceUrl) {
        for (const tool of tools) {
            try {
                // 查找或创建分类
                let category = await Category.findOne({ name: tool.category });
                if (!category) {
                    category = await Category.create({ name: tool.category });
                }

                // 创建工具
                const newTool = {
                    name: tool.name,
                    url: tool.url,
                    description: tool.description,
                    category: category._id,
                    source: sourceUrl
                };

                // 检查是否已存在
                const exists = await Tool.findOne({ 
                    $or: [
                        { name: tool.name },
                        { url: tool.url }
                    ]
                });

                if (!exists) {
                    await Tool.create(newTool);
                    console.log(`保存工具: ${tool.name}`);
                } else {
                    console.log(`工具已存在，跳过: ${tool.name}`);
                }
            } catch (error) {
                console.error(`保存工具 ${tool.name} 时出错:`, error);
            }
        }
    }
}

module.exports = new AiToolsCrawler();
