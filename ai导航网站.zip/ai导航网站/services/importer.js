const csv = require('csv-parser');
const fs = require('fs');
const Tool = require('../models/Tool');
const Category = require('../models/Category');

class ToolsImporter {
    constructor() {
        this.results = {
            total: 0,
            success: 0,
            failed: 0,
            skipped: 0
        };
    }

    // 从CSV文件导入
    async importFromCsv(filePath) {
        return new Promise((resolve, reject) => {
            const tools = [];
            
            fs.createReadStream(filePath)
                .pipe(csv())
                .on('data', (data) => tools.push(data))
                .on('end', async () => {
                    try {
                        await this.processTools(tools);
                        resolve(this.results);
                    } catch (error) {
                        reject(error);
                    }
                })
                .on('error', (error) => reject(error));
        });
    }

    // 从JSON文件导入
    async importFromJson(filePath) {
        try {
            const data = fs.readFileSync(filePath, 'utf8');
            const tools = JSON.parse(data);
            await this.processTools(tools);
            return this.results;
        } catch (error) {
            throw new Error(`JSON导入错误: ${error.message}`);
        }
    }

    // 处理工具数据
    async processTools(tools) {
        this.results.total = tools.length;

        for (const tool of tools) {
            try {
                // 检查必需字段
                if (!this.validateTool(tool)) {
                    this.results.failed++;
                    continue;
                }

                // 检查是否已存在
                const exists = await Tool.findOne({ 
                    $or: [
                        { name: tool.name },
                        { url: tool.url }
                    ]
                });

                if (exists) {
                    this.results.skipped++;
                    continue;
                }

                // 处理分类
                let category = await Category.findOne({ name: tool.category });
                if (!category) {
                    category = await Category.create({
                        name: tool.category,
                        icon: 'fas fa-robot',
                        description: `${tool.category}相关工具`
                    });
                }

                // 创建新工具
                const newTool = new Tool({
                    name: tool.name,
                    description: tool.description,
                    company: tool.company || '未知',
                    category: category._id,
                    price: tool.price || '未知',
                    url: tool.url,
                    image: tool.image || '/images/default-tool.png',
                    isNew: true
                });

                await newTool.save();
                this.results.success++;
            } catch (error) {
                console.error(`处理工具 ${tool.name} 失败:`, error);
                this.results.failed++;
            }
        }
    }

    // 验证工具数据
    validateTool(tool) {
        const requiredFields = ['name', 'description', 'url'];
        return requiredFields.every(field => tool[field] && tool[field].trim());
    }

    // 生成示例CSV模板
    static generateCsvTemplate(outputPath) {
        const header = 'name,description,company,category,price,url,image\n';
        const example = 'Example Tool,This is a description,Company Name,AI助手,免费版本,https://example.com,https://example.com/image.jpg\n';
        
        fs.writeFileSync(outputPath, header + example);
    }

    // 生成示例JSON模板
    static generateJsonTemplate(outputPath) {
        const template = {
            tools: [
                {
                    name: "Example Tool",
                    description: "This is a description",
                    company: "Company Name",
                    category: "AI助手",
                    price: "免费版本",
                    url: "https://example.com",
                    image: "https://example.com/image.jpg"
                }
            ]
        };

        fs.writeFileSync(outputPath, JSON.stringify(template, null, 2));
    }
}

module.exports = ToolsImporter;
