const cron = require('node-cron');
const AiToolsCrawler = require('./crawler');
const { sendNotification } = require('../utils/notification');

class ScheduledTasks {
    constructor() {
        this.crawler = new AiToolsCrawler();
    }

    // 初始化所有定时任务
    init() {
        this.scheduleDailyCrawl();
    }

    // 每天凌晨2点运行爬虫
    scheduleDailyCrawl() {
        cron.schedule('0 2 * * *', async () => {
            console.log('开始每日AI工具更新...');
            try {
                const startTime = new Date();
                const newToolsCount = await this.crawler.crawl();
                const endTime = new Date();
                const duration = (endTime - startTime) / 1000;

                const message = `
                    AI工具更新完成:
                    - 新增工具数: ${newToolsCount}
                    - 耗时: ${duration}秒
                    - 时间: ${startTime.toLocaleString()}
                `;

                console.log(message);
                
                // 如果有新工具，发送通知
                if (newToolsCount > 0) {
                    await sendNotification({
                        title: 'AI工具库更新',
                        message: `发现${newToolsCount}个新的AI工具`,
                        type: 'success'
                    });
                }
            } catch (error) {
                console.error('AI工具更新失败:', error);
                await sendNotification({
                    title: 'AI工具库更新失败',
                    message: error.message,
                    type: 'error'
                });
            }
        }, {
            scheduled: true,
            timezone: "Asia/Shanghai"
        });
    }
}

module.exports = new ScheduledTasks();
