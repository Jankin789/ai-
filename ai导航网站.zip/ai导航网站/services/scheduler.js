const cron = require('node-cron');
const AiToolsCrawler = require('./crawler');
const Tool = require('../models/Tool');

class SchedulerService {
    constructor() {
        this.crawler = new AiToolsCrawler();
    }

    // 启动所有计划任务
    start() {
        // 每天凌晨2点运行爬虫
        cron.schedule('0 2 * * *', () => {
            this.runCrawler();
        });

        // 每周一清理旧的"新工具"标记
        cron.schedule('0 0 * * 1', () => {
            this.cleanupNewFlags();
        });

        // 每小时更新工具统计
        cron.schedule('0 * * * *', () => {
            this.updateStatistics();
        });
    }

    // 运行爬虫
    async runCrawler() {
        console.log('开始运行自动爬虫...');
        try {
            const newTools = await this.crawler.crawl();
            console.log(`爬虫运行完成，新增 ${newTools} 个工具`);
        } catch (error) {
            console.error('爬虫运行失败:', error);
        }
    }

    // 清理旧的"新工具"标记
    async cleanupNewFlags() {
        try {
            // 清理7天前添加的工具的"新工具"标记
            const oneWeekAgo = new Date();
            oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

            await Tool.updateMany(
                { 
                    createdAt: { $lt: oneWeekAgo },
                    isNew: true
                },
                { 
                    $set: { isNew: false }
                }
            );

            console.log('清理旧的"新工具"标记完成');
        } catch (error) {
            console.error('清理"新工具"标记失败:', error);
        }
    }

    // 更新工具统计
    async updateStatistics() {
        try {
            const stats = await Tool.aggregate([
                {
                    $group: {
                        _id: null,
                        totalTools: { $sum: 1 },
                        totalViews: { $sum: '$views' },
                        freeTools: {
                            $sum: {
                                $cond: [{ $eq: ['$price', '免费版本'] }, 1, 0]
                            }
                        }
                    }
                }
            ]);

            // 这里可以将统计数据保存到缓存或数据库中
            console.log('统计数据更新完成');
        } catch (error) {
            console.error('更新统计数据失败:', error);
        }
    }
}

module.exports = SchedulerService;
