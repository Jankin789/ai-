const axios = require('axios');

async function testSystem() {
    try {
        // 1. 登录获取token
        console.log('1. 测试登录...');
        const loginResponse = await axios.post('http://localhost:3000/api/auth/login', {
            email: 'admin@example.com',
            password: 'admin123'
        });
        const token = loginResponse.data.token;
        console.log('登录成功，获取到token');

        // 设置认证头
        const config = {
            headers: { 'Authorization': `Bearer ${token}` }
        };

        // 2. 触发爬虫
        console.log('\n2. 触发爬虫...');
        const crawlResponse = await axios.post('http://localhost:3000/api/management/crawl', {}, config);
        console.log('爬虫响应:', crawlResponse.data);

        // 3. 获取工具列表
        console.log('\n3. 获取工具列表...');
        const toolsResponse = await axios.get('http://localhost:3000/api/tools');
        console.log(`获取到 ${toolsResponse.data.length} 个工具`);

        // 4. 获取分类列表
        console.log('\n4. 获取分类列表...');
        const categoriesResponse = await axios.get('http://localhost:3000/api/categories');
        console.log(`获取到 ${categoriesResponse.data.length} 个分类`);

        // 5. 添加测试工具
        console.log('\n5. 添加测试工具...');
        const testTool = {
            name: "测试AI工具",
            description: "这是一个用于测试的AI工具",
            company: "测试公司",
            price: "免费版本",
            url: "https://example.com",
            image: "https://example.com/image.jpg",
            category: categoriesResponse.data[0]?._id // 使用第一个分类
        };
        const addToolResponse = await axios.post('http://localhost:3000/api/tools', testTool, config);
        console.log('添加工具响应:', addToolResponse.data);

    } catch (error) {
        console.error('测试过程中出现错误:', error.response?.data || error.message);
    }
}

testSystem();
