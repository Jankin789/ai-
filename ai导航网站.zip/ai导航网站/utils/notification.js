const Notification = require('../models/Notification');

// 发送通知
async function sendNotification({ title, message, type = 'info' }) {
    try {
        const notification = new Notification({
            title,
            message,
            type,
            timestamp: new Date()
        });
        await notification.save();
        return true;
    } catch (error) {
        console.error('发送通知失败:', error);
        return false;
    }
}

// 获取未读通知
async function getUnreadNotifications() {
    try {
        return await Notification.find({ read: false })
            .sort({ timestamp: -1 })
            .limit(10);
    } catch (error) {
        console.error('获取未读通知失败:', error);
        return [];
    }
}

// 标记通知为已读
async function markNotificationAsRead(notificationId) {
    try {
        await Notification.findByIdAndUpdate(notificationId, { read: true });
        return true;
    } catch (error) {
        console.error('标记通知失败:', error);
        return false;
    }
}

module.exports = {
    sendNotification,
    getUnreadNotifications,
    markNotificationAsRead
};
